package com.example.huecontrol;

import android.app.Activity;
import android.os.Bundle;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.view.MotionEvent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 final ExecutorService worker=Executors.newSingleThreadExecutor();
 LinearLayout shell, body, sidebar, cards, settingsPage; TextView status, connection; EditText ip;
 final ArrayList<Lamp> lamps=new ArrayList<>(); final ArrayList<Scene> scenes=new ArrayList<>(); final ArrayList<Room> rooms=new ArrayList<>(); boolean dark=true; int page=0;
 boolean editing=false; FrameLayout widgetCanvas; final LinkedHashMap<String,Widget> widgets=new LinkedHashMap<>();
 int accent(){return dark?0xffb69aff:0xff6945ca;}
 int good(){return dark?0xff63d8b0:0xff158766;}
 int border(){return dark?0xff303750:0xffe0e3ef;}
 int secondaryPanel(){return dark?0xff222940:0xfff0f1f8;}
 int lampTint(Lamp l){if(!l.on)return muted();if(l.color){float[] hsv={l.hue*360f/65535f,.65f,1f};return Color.HSVToColor(hsv);}return l.ct?0xffffc98b:0xffffdbaa;}
 GradientDrawable stroke(int color,int radius,int line){GradientDrawable d=shape(color,radius);d.setStroke(dp(1),line);return d;}
 void tintText(TextView v,int color){v.setTextColor(color);}
 void applySwitch(Switch sw){sw.setThumbTintList(ColorStateList.valueOf(Color.WHITE));sw.setTrackTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{accent(),dark?0xff555e75:0xffb5bbca}));}
 void applySeek(SeekBar sb,int color){sb.setProgressTintList(ColorStateList.valueOf(color));sb.setThumbTintList(ColorStateList.valueOf(color));sb.setProgressBackgroundTintList(ColorStateList.valueOf(dark?0xff424a61:0xffd7dae5));}
 GradientDrawable rainbow(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xfffb657a,0xffffbd63,0xffd8e76a,0xff54d9b7,0xff5faaff,0xffad82ff,0xfffb657a});d.setCornerRadius(dp(20));return d;}
 void spectrum(SeekBar sb){sb.setProgressDrawable(rainbow());sb.setThumbTintList(ColorStateList.valueOf(Color.WHITE));}
 void elevation(View v){v.setElevation(dp(dark?0:2));}
 int bg(){return dark?0xff0d1120:0xfff5f6fa;} int panel(){return dark?0xff1b2236:Color.WHITE;} int fg(){return dark?0xfff5f5fb:0xff1c2335;} int muted(){return dark?0xff9ba6bf:0xff6b7488;}
 String pref(String k){return getPreferences(0).getString(k,"");}
 String address(){return pref("ip");} String key(){return pref("key");}
 int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 @Override public void onCreate(Bundle b){super.onCreate(b);dark=getPreferences(0).getBoolean("dark",true);render();if(!key().isEmpty()&&!address().isEmpty())load();}
 GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(fg());t.setTextSize(size);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));else t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));t.setIncludeFontPadding(false);return t;}
 void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
 void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
 TextView addText(LinearLayout p,String s,int size,boolean bold){TextView t=text(s,size,bold);p.addView(t);return t;}
 void button(LinearLayout p,String s,Runnable r){TextView t=text(s,14,true);t.setGravity(Gravity.CENTER);pad(t,15,13,15,13);t.setBackground(shape(accent(),12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);p.addView(t,lp);t.setOnClickListener(v->r.run());}
 void render(){
  getWindow().setStatusBarColor(bg());getWindow().setNavigationBarColor(bg());getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
  shell=new LinearLayout(this);shell.setOrientation(1);shell.setBackgroundColor(bg());setContentView(shell);
  int widthDp=getResources().getConfiguration().screenWidthDp;
  boolean wide=widthDp>=700;
  LinearLayout layout=new LinearLayout(this);layout.setOrientation(wide?0:1);shell.addView(layout,new LinearLayout.LayoutParams(-1,-1));
  sidebar=vertical();pad(sidebar,wide?22:18,wide?32:16,wide?22:18,wide?18:12);sidebar.setBackgroundColor(panel());
  if(wide)layout.addView(sidebar,new LinearLayout.LayoutParams(dp(widthDp>=1100?238:204),-1));else layout.addView(sidebar,new LinearLayout.LayoutParams(-1,-2));
  TextView logo=addText(sidebar,"◉  HUE CONTROL",wide?19:17,true);logo.setLetterSpacing(.035f);gap(sidebar,wide?35:12);
  if(wide){nav("⌂   Kontrol paneli",0);nav("⚙   Ayarlar",1);gap(sidebar,26);TextView info=addText(sidebar,key().isEmpty()?"○  Bridge bağlı değil":"●  Yerel Bridge",12,true);info.setTextColor(key().isEmpty()?muted():good());}
  else {LinearLayout tabs=new LinearLayout(this);sidebar.addView(tabs);tab(tabs,"⌂  Kontrol",0);tab(tabs,"⚙  Ayarlar",1);}
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);layout.addView(scroll,new LinearLayout.LayoutParams(wide?0:-1,wide?-1:0,1));
  body=vertical();pad(body,wide?30:18,wide?28:20,wide?30:18,35);scroll.addView(body);
  if(page==0)showDashboard();else showSettings();
 }
 void nav(String name,int n){TextView t=text(name,15,page==n);pad(t,16,17,10,17);if(page==n){t.setBackground(shape(dark?0xff3a315d:0xffeae2ff,15));t.setTextColor(dark?0xffeee4ff:0xff5a38b6);}else t.setTextColor(muted());sidebar.addView(t);gap(sidebar,8);t.setOnClickListener(v->{page=n;render();});}
 void tab(LinearLayout p,String name,int n){TextView t=text(name,14,page==n);pad(t,16,10,16,10);if(page==n){t.setBackground(shape(dark?0xff3a315d:0xffeae2ff,11));t.setTextColor(accent());}p.addView(t);t.setOnClickListener(v->{page=n;render();});}
 void showDashboard(){
  LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);body.addView(header);
  LinearLayout headings=vertical();header.addView(headings,new LinearLayout.LayoutParams(0,-2,1));
  addText(headings,"Evinin ışıkları",28,true);gap(headings,7);
  TextView conn=addText(headings,key().isEmpty()?"○  Bridge eşleştirilmedi":"●  Bridge bağlı  ·  "+lamps.size()+" cihaz",13,false);conn.setTextColor(key().isEmpty()?muted():good());
  TextView edit=text(editing?"✓  Tamam":"✎  Düzenle",13,true);pad(edit,15,12,15,12);edit.setBackground(stroke(editing?accent():panel(),13,editing?accent():border()));header.addView(edit);edit.setOnClickListener(v->{editing=!editing;render();});gap(body,24);
  LinearLayout actions=new LinearLayout(this);body.addView(actions);smallButton(actions,"☀  Tümünü aç",()->all(true));smallButton(actions,"☾  Tümünü kapat",()->all(false));gap(body,18);
  if(editing){button(body,"＋  Widget ekle",()->chooseWidget());TextView hint=addText(body,"Kart başlığından taşı  ·  Sağ alt köşeden boyutlandır  ·  × ile kaldır",12,false);hint.setTextColor(muted());gap(body,18);}
  showScenes();showRooms();LinearLayout row= new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);body.addView(row);
  TextView title=text("Işıklar",19,true);row.addView(title,new LinearLayout.LayoutParams(0,-2,1));TextView count=text(lamps.size()+" lamba",12,false);count.setTextColor(muted());row.addView(count);gap(body,15);
  widgetCanvas=new FrameLayout(this);widgetCanvas.setClipChildren(false);widgetCanvas.setClipToPadding(false);
  body.addView(widgetCanvas,new LinearLayout.LayoutParams(-1,dp(700)));
  ensureWidgets();widgetCanvas.post(()->{if(widgetCanvas!=null)drawWidgets();});
  status=addText(body,"",12,false);status.setTextColor(muted());
 }
 void smallButton(LinearLayout parent,String label,Runnable action){TextView t=text(label,13,true);t.setGravity(Gravity.CENTER);pad(t,14,11,14,11);t.setBackground(stroke(panel(),13,border()));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(3),0,dp(3),0);parent.addView(t,lp);t.setOnClickListener(v->action.run());}
 static class Widget {String id;int x,y,w,h;Widget(String id,int x,int y,int w,int h){this.id=id;this.x=x;this.y=y;this.w=w;this.h=h;}}
 String widgetPref(){return "widgets_v5_"+(getResources().getConfiguration().orientation==Configuration.ORIENTATION_PORTRAIT?"portrait":"landscape");}
 void saveWidgets(){JSONArray a=new JSONArray();for(Widget w:widgets.values()){JSONObject o=new JSONObject();try{o.put("id",w.id);o.put("x",w.x);o.put("y",w.y);o.put("w",w.w);o.put("h",w.h);a.put(o);}catch(Exception ignored){}}getPreferences(0).edit().putString(widgetPref(),a.toString()).apply();}
 void ensureWidgets(){if(!widgets.isEmpty())return;String saved=pref(widgetPref());if(!saved.isEmpty()){try{JSONArray a=new JSONArray(saved);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String id=o.getString("id");widgets.put(id,new Widget(id,o.optInt("x"),o.optInt("y"),o.optInt("w",280),o.optInt("h",260)));}if(a.length()>0||lamps.isEmpty())return;}catch(Exception ignored){}}
  // New orientation gets its own layout; portrait is stacked to prevent collisions.
  int col=0,row=0;int cols=getResources().getConfiguration().screenWidthDp>=1100?3:(getResources().getConfiguration().screenWidthDp>=650?2:1);for(Lamp l:lamps){widgets.put(l.id,new Widget(l.id,col*304,row*320,286,302));col++;if(col==cols){col=0;row++;}}}
 Lamp lamp(String id){for(Lamp l:lamps)if(l.id.equals(id))return l;return null;}
 void chooseWidget(){ArrayList<Lamp> available=new ArrayList<>();for(Lamp l:lamps)if(!widgets.containsKey(l.id))available.add(l);if(available.isEmpty()){Toast.makeText(this,"Eklenebilecek başka lamba yok.",Toast.LENGTH_SHORT).show();return;}String[] names=new String[available.size()];for(int i=0;i<names.length;i++)names[i]=available.get(i).name;
  new android.app.AlertDialog.Builder(this).setTitle("Widget ekle").setItems(names,(d,which)->{Lamp l=available.get(which);int y=0;for(Widget w:widgets.values())y=Math.max(y,w.y+w.h+12);widgets.put(l.id,new Widget(l.id,0,y,286,242));saveWidgets();drawWidgets();}).setNegativeButton("Vazgeç",null).show();}
 void drawWidgets(){if(widgetCanvas==null)return;widgetCanvas.removeAllViews();float density=getResources().getDisplayMetrics().density;int available=Math.max(dp(190),widgetCanvas.getWidth());int availableDp=(int)(available/density);int maxBottom=350; boolean narrow=availableDp<610; int index=0;
  for(Widget w:widgets.values()){Lamp l=lamp(w.id);if(l==null)continue;w.w=Math.max(190,Math.min(w.w,availableDp));w.h=Math.max(280,w.h);if(narrow){w.x=0;w.y=index*(Math.max(302,w.h)+14);w.w=availableDp;w.h=Math.max(302,w.h);}else{w.x=Math.max(0,Math.min(w.x,availableDp-w.w));}index++;
   LinearLayout card=vertical();pad(card,18,17,18,12);card.setBackground(stroke(panel(),20,editing?accent():border()));elevation(card);
   FrameLayout.LayoutParams pos=new FrameLayout.LayoutParams(dp(w.w),dp(w.h));pos.leftMargin=dp(Math.max(0,Math.min(w.x,availableDp-w.w)));pos.topMargin=dp(Math.max(0,w.y));widgetCanvas.addView(card,pos);
   LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);card.addView(top);
   TextView dot=text("●",16,true);dot.setTextColor(lampTint(l));LinearLayout.LayoutParams dotp=new LinearLayout.LayoutParams(-2,-2);dotp.rightMargin=dp(9);top.addView(dot,dotp);
   TextView name=text(l.name,16,true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
   if(editing){TextView remove=text("×",23,true);pad(remove,9,0,5,0);top.addView(remove);remove.setOnClickListener(v->{widgets.remove(w.id);saveWidgets();drawWidgets();});attachDrag(name,card,w);attachDrag(dot,card,w);}
   else {Switch sw=new Switch(this);sw.setChecked(l.on);applySwitch(sw);top.addView(sw);sw.setOnCheckedChangeListener((v,on)->{l.on=on;dot.setTextColor(lampTint(l));setLight(l.id,"{\"on\":"+on+"}");});}
   gap(card,7);TextView subtitle=addText(card,l.on?"Açık · Hazır":"Kapalı",12,false);subtitle.setTextColor(muted());gap(card,10);
   LinearLayout dimHeader=new LinearLayout(this);card.addView(dimHeader);TextView label=text("Parlaklık",12,false);label.setTextColor(muted());dimHeader.addView(label,new LinearLayout.LayoutParams(0,-2,1));TextView pct=text(Math.round(l.bri*100f/254)+"%",12,true);dimHeader.addView(pct);
   SeekBar dim=new SeekBar(this);dim.setMax(254);dim.setProgress(l.bri);applySeek(dim,accent());card.addView(dim);dim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean user){if(user)pct.setText(Math.round(p*100f/254)+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){l.bri=Math.max(1,s.getProgress());setLight(l.id,"{\"on\":true,\"bri\":"+l.bri+"}");}});
   if(l.color){TextView hue=addText(card,"Renk tonu",12,false);hue.setTextColor(muted());SeekBar h=new SeekBar(this);h.setMax(65535);h.setProgress(l.hue);spectrum(h);card.addView(h);h.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){l.hue=p;dot.setTextColor(lampTint(l));setLight(l.id,"{\"on\":true,\"hue\":"+p+",\"sat\":254}");}});}
   if(l.ct){TextView ct=addText(card,"Beyaz sıcaklığı  ·  Sıcak — Soğuk",12,false);ct.setTextColor(muted());SeekBar temp=new SeekBar(this);temp.setMax(347);temp.setProgress(Math.max(0,Math.min(347,500-l.ctValue)));applySeek(temp,0xffffbc7e);card.addView(temp);temp.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){l.ctValue=500-p;setLight(l.id,"{\"on\":true,\"ct\":"+l.ctValue+"}");}});}
   if(editing){TextView handle=text("↘  Boyutlandır",11,true);handle.setTextColor(accent());handle.setGravity(Gravity.RIGHT);card.addView(handle,new LinearLayout.LayoutParams(-1,-2));attachResize(handle,card,w);}
   maxBottom=Math.max(maxBottom,w.y+w.h+20);
  }
  widgetCanvas.getLayoutParams().height=dp(maxBottom);widgetCanvas.requestLayout();
 }
 void attachDrag(View grip,View card,Widget w){grip.setOnTouchListener(new View.OnTouchListener(){float downX,downY;int startX,startY;public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();startX=w.x;startY=w.y;return true;case MotionEvent.ACTION_MOVE:int maxX=Math.max(0,(int)(widgetCanvas.getWidth()/getResources().getDisplayMetrics().density)-w.w);w.x=Math.max(0,Math.min(maxX,startX+(int)((e.getRawX()-downX)/getResources().getDisplayMetrics().density)));w.y=Math.max(0,startY+(int)((e.getRawY()-downY)/getResources().getDisplayMetrics().density));FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)card.getLayoutParams();p.leftMargin=dp(w.x);p.topMargin=dp(w.y);card.setLayoutParams(p);return true;case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:saveWidgets();drawWidgets();return true;}return false;}});}
 void attachResize(View grip,View card,Widget w){grip.setOnTouchListener(new View.OnTouchListener(){float downX,downY;int startW,startH;public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();startW=w.w;startH=w.h;return true;case MotionEvent.ACTION_MOVE:int maxW=Math.max(190,(int)(widgetCanvas.getWidth()/getResources().getDisplayMetrics().density)-w.x);w.w=Math.max(190,Math.min(maxW,startW+(int)((e.getRawX()-downX)/getResources().getDisplayMetrics().density)));w.h=Math.max(210,Math.min(750,startH+(int)((e.getRawY()-downY)/getResources().getDisplayMetrics().density)));FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)card.getLayoutParams();p.width=dp(w.w);p.height=dp(w.h);card.setLayoutParams(p);return true;case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:saveWidgets();drawWidgets();return true;}return false;}});}
 void drawCards(){cards.removeAllViews();int width=getResources().getDisplayMetrics().widthPixels;int cols=getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE?(width>dp(1000)?3:2):1;
  LinearLayout line=null;for(int i=0;i<lamps.size();i++){if(i%cols==0){line=new LinearLayout(this);cards.addView(line,new LinearLayout.LayoutParams(-1,-2));}Lamp l=lamps.get(i);LinearLayout card=vertical();pad(card,17,17,17,16);card.setBackground(shape(panel(),18));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.setMargins(dp(5),dp(5),dp(5),dp(7));line.addView(card,cp);
   LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);card.addView(top);TextView name=text(l.name,17,true);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));Switch sw=new Switch(this);sw.setChecked(l.on);top.addView(sw);sw.setOnCheckedChangeListener((v,on)->{l.on=on;setLight(l.id,"{\"on\":"+on+"}");});
   gap(card,12);TextView pct=addText(card,"Parlaklık  "+Math.round(l.bri*100f/254)+"%",13,false);pct.setTextColor(muted());SeekBar dim=new SeekBar(this);dim.setMax(254);dim.setProgress(l.bri);card.addView(dim);dim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean user){if(user)pct.setText("Parlaklık  "+Math.round(p*100f/254)+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){l.bri=Math.max(1,s.getProgress());setLight(l.id,"{\"on\":true,\"bri\":"+l.bri+"}");}});
   if(l.color){gap(card,7);TextView hue=addText(card,"Renk",13,false);hue.setTextColor(muted());SeekBar h=new SeekBar(this);h.setMax(65535);h.setProgress(l.hue);card.addView(h);h.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){l.hue=p;setLight(l.id,"{\"on\":true,\"hue\":"+p+",\"sat\":254}");}});}
   if(l.ct){gap(card,7);TextView ct=addText(card,"Beyaz sıcaklığı • Sıcak ↔ Soğuk",12,false);ct.setTextColor(muted());SeekBar temp=new SeekBar(this);temp.setMax(347);temp.setProgress(Math.max(0,Math.min(347,500-l.ctValue)));card.addView(temp);temp.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){l.ctValue=500-p;setLight(l.id,"{\"on\":true,\"ct\":"+l.ctValue+"}");}});}
  }
 }
 abstract class StopSeek implements SeekBar.OnSeekBarChangeListener{public void onProgressChanged(SeekBar s,int p,boolean u){}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){stopped(s.getProgress());}public abstract void stopped(int p);}
 void showSettings(){addText(body,"Ayarlar",28,true);gap(body,20);addText(body,"Bridge bağlantısı",19,true);gap(body,8);ip=new EditText(this);ip.setSingleLine(true);ip.setTextColor(fg());ip.setHintTextColor(muted());ip.setHint("Bridge yerel IP adresi");ip.setText(address());body.addView(ip);gap(body,10);
  button(body,"IP adresini kaydet",()->{String a=ip.getText().toString().trim();if(!validIp(a)){message("Geçerli IPv4 adresi girin.");return;}getPreferences(0).edit().putString("ip",a).apply();message("Bridge IP kaydedildi.");});
  button(body,"Bridge ile eşleştir",()->pair());button(body,"Lambaları yenile",()->load());
  status=addText(body,key().isEmpty()?"Bridge henüz eşleştirilmedi.":"Bridge anahtarı kayıtlı.",13,false);status.setTextColor(muted());gap(body,24);
  addText(body,"Görünüm",19,true);Switch theme=new Switch(this);theme.setText("Koyu tema");theme.setTextColor(fg());theme.setTextSize(16);theme.setChecked(dark);body.addView(theme);theme.setOnCheckedChangeListener((v,on)->{dark=on;getPreferences(0).edit().putBoolean("dark",on).apply();render();});gap(body,24);
  addText(body,"Tüm lambalar ("+lamps.size()+")",19,true);gap(body,10);for(Lamp l:lamps){TextView t=addText(body,"• "+l.name+"   (ID: "+l.id+")",15,false);pad(t,5,9,5,9);}gap(body,20);addText(body,"Hue Control v5  ·  Yerel ağ kontrolü",12,false);
 }
 boolean validIp(String a){if(!a.matches("\\d{1,3}(\\.\\d{1,3}){3}"))return false;for(String part:a.split("\\."))if(Integer.parseInt(part)>255)return false;return true;}
 void message(String m){runOnUiThread(()->{if(status!=null)status.setText(m);else Toast.makeText(this,m,Toast.LENGTH_LONG).show();});}
 String request(String host,String path,String method,String payload)throws Exception{if(!validIp(host))throw new Exception("Geçersiz IP");HttpURLConnection c=(HttpURLConnection)new URL("http://"+host+path).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);c.setRequestMethod(method);if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(payload.getBytes("UTF-8"));}}try(InputStream in=c.getResponseCode()<400?c.getInputStream():c.getErrorStream()){if(in==null)throw new Exception("HTTP "+c.getResponseCode());return new String(in.readAllBytes(),"UTF-8");}finally{c.disconnect();}}
 void pair(){String host=ip==null?address():ip.getText().toString().trim();if(!validIp(host)){message("Önce geçerli IP girin.");return;}getPreferences(0).edit().putString("ip",host).apply();message("Bridge düğmesine basın ve tekrar eşleştirmeyi deneyin.");worker.execute(()->{try{JSONArray a=new JSONArray(request(host,"/api","POST","{\"devicetype\":\"huecontrol#android\"}"));JSONObject o=a.getJSONObject(0);if(o.has("success")){String k=o.getJSONObject("success").getString("username");getPreferences(0).edit().putString("key",k).apply();message("Eşleştirme başarılı.");load();}else message("Bridge düğmesine basın: "+o.optJSONObject("error").optString("description","Eşleştirme bekleniyor"));}catch(Exception e){message("Bağlantı hatası: "+e.getMessage());}});}
 void load(){String host=address(),token=key();if(token.isEmpty()||host.isEmpty()){message("Önce Bridge ile eşleştirin.");return;}worker.execute(()->{try{JSONObject data=new JSONObject(request(host,"/api/"+token+"/lights","GET",null));ArrayList<Lamp> fresh=new ArrayList<>();Iterator<String> ids=data.keys();while(ids.hasNext()){String id=ids.next();JSONObject o=data.optJSONObject(id);if(o==null)continue;JSONObject st=o.optJSONObject("state");if(st==null)st=new JSONObject();JSONObject caps=o.optJSONObject("capabilities");JSONObject control=caps==null?null:caps.optJSONObject("control");Lamp l=new Lamp();l.id=id;l.name=o.optString("name","Lamba "+id);l.on=st.optBoolean("on");l.bri=st.optInt("bri",127);l.hue=st.optInt("hue",0);l.ctValue=st.optInt("ct",350);String type=o.optString("type","");l.color=st.has("hue")||type.contains("color light");l.ct=st.has("ct")||type.contains("temperature");if(control!=null&&control.has("ct"))l.ct=true;fresh.add(l);}Collections.sort(fresh,(a,b)->a.name.compareToIgnoreCase(b.name));
   ArrayList<Scene> newScenes=new ArrayList<>();ArrayList<Room> newRooms=new ArrayList<>();
   try{JSONObject groups=new JSONObject(request(host,"/api/"+token+"/groups","GET",null));Iterator<String> gi=groups.keys();while(gi.hasNext()){String id=gi.next();JSONObject g=groups.optJSONObject(id);if(g==null||id.equals("0"))continue;Room room=new Room();room.id=id;room.name=g.optString("name","Oda");newRooms.add(room);}}catch(Exception ignored){}
   try{JSONObject list=new JSONObject(request(host,"/api/"+token+"/scenes","GET",null));Iterator<String> si=list.keys();while(si.hasNext()){String id=si.next();JSONObject o=list.optJSONObject(id);if(o==null)continue;String group=o.optString("group","");if(group.isEmpty()||group.equals("0"))continue;Scene sc=new Scene();sc.id=id;sc.name=o.optString("name","Sahne");sc.group=group;newScenes.add(sc);}}catch(Exception ignored){}
   Collections.sort(newScenes,(a,b)->a.name.compareToIgnoreCase(b.name));
   runOnUiThread(()->{lamps.clear();lamps.addAll(fresh);scenes.clear();scenes.addAll(newScenes);rooms.clear();rooms.addAll(newRooms);widgets.clear();render();message(lamps.size()+" lamba, "+scenes.size()+" sahne yüklendi.");});}catch(Exception e){message("Okuma hatası: "+e.getMessage());}});}
 void setLight(String id,String payload){String host=address(),token=key();worker.execute(()->{try{String result=request(host,"/api/"+token+"/lights/"+id+"/state","PUT",payload);JSONArray a=new JSONArray(result);if(a.length()>0&&a.getJSONObject(0).has("error"))message("Hue hatası: "+a.getJSONObject(0).getJSONObject("error").optString("description"));}catch(Exception e){message("Kontrol hatası: "+e.getMessage());}});}
 static class Scene{String id,name,group;}
 static class Room{String id,name;}
 void activateScene(Scene sc){String host=address(),token=key();worker.execute(()->{try{JSONArray response=new JSONArray(request(host,"/api/"+token+"/groups/"+sc.group+"/action","PUT","{\"scene\":\""+sc.id+"\"}"));if(response.length()>0&&response.getJSONObject(0).has("error"))message("Sahne hatası: "+response.getJSONObject(0).getJSONObject("error").optString("description"));else{message(sc.name+" sahnesi etkinleştirildi.");}}catch(Exception e){message("Sahne hatası: "+e.getMessage());}});}
 void setRoom(Room room,boolean on){String host=address(),token=key();worker.execute(()->{try{request(host,"/api/"+token+"/groups/"+room.id+"/action","PUT","{\"on\":"+on+"}");message(room.name+" güncellendi.");}catch(Exception e){message("Oda kontrol hatası: "+e.getMessage());}});}
 void showScenes(){if(scenes.isEmpty())return;addText(body,"Görünümlerim",19,true);gap(body,10);HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);body.addView(scroll);LinearLayout row=new LinearLayout(this);scroll.addView(row);for(Scene sc:scenes){LinearLayout tile=vertical();tile.setGravity(Gravity.CENTER);pad(tile,14,16,14,16);tile.setBackground(stroke(panel(),18,border()));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(146),dp(114));lp.rightMargin=dp(12);row.addView(tile,lp);TextView symbol=addText(tile,"✦",27,true);symbol.setGravity(Gravity.CENTER);symbol.setTextColor(accent());gap(tile,8);TextView label=addText(tile,sc.name,13,true);label.setGravity(Gravity.CENTER);label.setMaxLines(2);tile.setOnClickListener(v->activateScene(sc));}gap(body,24);}
 void showRooms(){if(rooms.isEmpty())return;addText(body,"Odalar ve bölgeler",19,true);gap(body,10);HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);body.addView(scroll);LinearLayout row=new LinearLayout(this);scroll.addView(row);for(Room room:rooms){LinearLayout tile=vertical();pad(tile,14,12,14,12);tile.setBackground(stroke(panel(),16,border()));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(188),-2);lp.rightMargin=dp(12);row.addView(tile,lp);addText(tile,room.name,14,true);gap(tile,8);LinearLayout actions=new LinearLayout(this);tile.addView(actions);smallButton(actions,"Aç",()->setRoom(room,true));smallButton(actions,"Kapat",()->setRoom(room,false));}gap(body,24);}
 void all(boolean on){for(Lamp l:lamps){l.on=on;setLight(l.id,"{\"on\":"+on+"}");}render();}
 static class Lamp{String id,name;boolean on,color,ct;int bri,hue,ctValue;}
 @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
}
