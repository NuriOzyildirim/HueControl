# Hue Control V11 - Haftalık Program ve Termostat Geçmişi

- Her gün dört zaman aralığı için 15-30 C set değeri.
- Haftalık program isteğe bağlı, varsayılan kapalı.
- Priz komutu doğrulandıktan sonra son 1000 aç/kapat olayı yerel olarak kaydedilir.
- Son 24 saat tahmini açık kalma süresi ve olay geçmişi.
- Eski Hue/SmartThings bağlantı bilgileri uygulama verisinde korunur (aynı imza ile güncelleme koşuluyla).
- Bridge IP default: 100.35.15.71. SmartThings token kaynak koduna gömülmez.
- ÖNEMLİ: Android ön plan servisi veya donanımsal watchdog yok. Tablet veya ağ kesilirse priz açık kalabilir. Kombiyle gözetimsiz kullanım için uygun değildir.
- GitHub Actions üzerinde kalıcı imzalama henüz yapılandırılmadı.
- Android SDK derleme testi yapılamadı.
