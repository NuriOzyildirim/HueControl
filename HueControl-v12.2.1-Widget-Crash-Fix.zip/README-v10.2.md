# Hue Control V10.2 - Termostat kontrollü test sürümü

- Hue Bridge varsayılan IP: 100.35.15.71 (yalnızca daha önce kaydedilmemişse).
- SmartThings erişim anahtarı **güvenlik nedeniyle ZIP / kaynak koda gömülmez**. Önceden kaydedilmiş token aynı APK imzasıyla yapılan güncellemede korunur.
- Termostat: 15-30 C set, 0.5 C adım, SmartThings sensörü ve Hue priz seçimi.
- Kullanıcı Ayarlar > Termostat üzerinden CANLI KONTROL'ü özellikle etkinleştirdiğinde, seçilen Hue prize aç/kapat komutu gönderir. +/- 0.3 C histerezis ve 3 dakika komut aralığı uygulanır.
- API komutundan sonra Hue cihaz durumu okunarak doğrulama denenir. 90 saniyeden uzun SmartThings sorgu hatasında priz kapatma komutu denenir.
- ÖNEMLİ: Bu uygulama sadece Activity açıkken denetler. Arka planda sürekli çalışan servis / bağımsız watchdog yoktur. Tablet donarsa, Android uygulamayı durdurursa veya ağ kesilirse röle AÇIK KALABİLİR. Bu sürüm kombiyle gözetimsiz kullanım için güvenli değildir. Donanımsal zaman aşımı ve bağımsız limit termostatı olmadan devreye almayın.
- V10 widget ve 24 saat grafik özellikleri korunur.
- Paket kimliği com.example.huecontrol ve versionCode 12. Önceki APK üzerine güncelleme yalnızca aynı imzayla mümkündür.
- Android SDK derlemesi / cihaz testi yapılmamıştır.
