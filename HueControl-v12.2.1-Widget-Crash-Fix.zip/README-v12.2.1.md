# V12.2.1 UI crash fix
- During widget touch, do not rebuild view tree. On ACTION_UP persist geometry without drawWidgets.
- Ignore stale posted widget redraw callbacks.
- Avoid periodic full render during edit gestures.
- Thermostat set changes update text labels in place, no full render or dialog flicker.
- Thermostat service and Hue relay algorithm unchanged.
- Android build and device runtime NOT verified.
