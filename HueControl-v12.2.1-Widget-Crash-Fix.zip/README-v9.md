# Hue Control V9 — Test sürümü

- V8 Hue/SmartThings dinamik kartlar ve polling korunur.
- Dış hava: Open-Meteo geocoding + current temperature; şehir Ayarlar bölümünden seçilir, varsayılan İzmir.
- İç/dış sıcaklık farkına göre kartın tamamı kırmızı/mavi/nötr renge geçer.
- SmartThings hava sensörü CO2 geçmişi, uygulama açıkken 5 dakikada bir yerel olarak kaydedilir (en çok 96 nokta); sensör kartında çizgi grafiği.
- Hava verisi 10 dakikada bir sorgulanır. Ağ hatasında mevcut son değer korunur ve durum açıklaması değişir.

Not: Geçmiş veriler kurulumdan itibaren birikir; SmartThings geçmiş API verisi çekilmez. PM2.5 eşlemesi önceki V8 davranışındadır. Android APK derlemesi burada doğrulanmamıştır.
