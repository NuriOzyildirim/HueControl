# Hue Control V10 — Gelişmiş Widget ve 24 Saat Sensör Grafikleri (beta)

- Düzenle > Widget ekle menüsünde Hue cihazlarının yanı sıra SmartThings sensörleri de seçilebilir.
- Sensör widget'ları taşınabilir, boyutlandırılabilir ve kaldırılabilir; yerleşim yön bazında saklanır.
- SmartThings sensör kartına veya widget'ına dokununca detay penceresi açılır.
- Hava istasyonu için sıcaklık, nem, CO2 ve PM2.5 ayrı ayrı son 24 saatlik grafiklerde gösterilir.
- Veriler uygulama çalışırken SmartThings'ten alındıkça cihazda 5 dakika aralıkla kaydedilir. Geçmiş veriler API'den geriye dönük çekilmez.
- Grafik en az iki kayıt oluşunca çizilir; 24 saatlik geçmişin dolması 24 saat sürer.
- PM2.5 SmartThings API'de sunulmuyorsa grafik boş kalır.
- PIR kartları ayrıntıda anlık hareket ve pil gösterir; hareket geçmişi henüz yoktur.

## Kurulum
GitHub Actions unzip adını `HueControl-v10-Widgets-Charts.zip` olarak güncelleyin.

## Sınırlar
Android SDK derlemesi ve gerçek tablet testi yapılmadı. V9 özellikleri temel alındı. Kombi termostatı bu sürüme dahil değildir.
