package com.example.huecontrol;

import android.app.*;
import android.content.*;
import android.os.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Foreground controller. No guarantee of physical fail-safe when Android or the network stops. */
public class ThermostatService extends Service {
 static final String CHANNEL="hue_thermostat_v12";
 final ScheduledExecutorService executor=Executors.newSingleThreadScheduledExecutor();
 volatile boolean busy=false;
 long lastChange=0; boolean lastKnownOn=false; boolean haveState=false;
 SharedPreferences prefs(){return getSharedPreferences("MainActivity",MODE_PRIVATE);}
 String pref(String key){return prefs().getString(key,"");}
 @Override public void onCreate(){super.onCreate();NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Hue Control termostat",NotificationManager.IMPORTANCE_LOW));startForeground(1201,notification("Termostat hazırlanıyor"));executor.scheduleWithFixedDelay(this::tick,0,15,TimeUnit.SECONDS);}
 @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
 @Override public android.os.IBinder onBind(Intent i){return null;}
 @Override public void onDestroy(){executor.shutdownNow();super.onDestroy();}
 Notification notification(String status){Intent intent=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Hue Control · Termostat").setContentText(status).setContentIntent(pi).setOngoing(true).build();}
 void notifyStatus(String msg){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(1201,notification(msg));prefs().edit().putString("thermostatServiceStatus",msg).putLong("thermostatServiceUpdated",System.currentTimeMillis()).apply();}
 String token()throws Exception{byte[] all=android.util.Base64.decode(pref("smartToken"),android.util.Base64.NO_WRAP);if(all.length<29)throw new Exception("Token eksik");byte[] iv=Arrays.copyOfRange(all,0,12);java.security.KeyStore ks=java.security.KeyStore.getInstance("AndroidKeyStore");ks.load(null);javax.crypto.Cipher c=javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,ks.getKey("huecontrol_smart",null),new GCMParameterSpec(128,iv));return new String(c.doFinal(Arrays.copyOfRange(all,12,all.length)),"UTF-8");}
 String http(String url,String method,String payload,String bearer)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(8000);c.setRequestMethod(method);if(bearer!=null)c.setRequestProperty("Authorization","Bearer "+bearer);if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream out=c.getOutputStream()){out.write(payload.getBytes("UTF-8"));}}try{int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();String result=in==null?"":new String(in.readAllBytes(),"UTF-8");if(code>=400)throw new IOException("HTTP "+code);return result;}finally{c.disconnect();}}
 double temperature(JSONObject root){JSONObject components=root.optJSONObject("components");if(components==null)return Double.NaN;Iterator<String> ids=components.keys();while(ids.hasNext()){JSONObject component=components.optJSONObject(ids.next());if(component==null)continue;JSONObject cap=component.optJSONObject("temperatureMeasurement");if(cap==null)continue;JSONObject attr=cap.optJSONObject("temperature");if(attr!=null)return attr.optDouble("value",Double.NaN);}return Double.NaN;}
 double target(){double base=prefs().getFloat("thermostatSet",23f);if(!prefs().getBoolean("scheduleEnabled",false))return base;Calendar c=Calendar.getInstance();int day=(c.get(Calendar.DAY_OF_WEEK)+5)%7;int hour=c.get(Calendar.HOUR_OF_DAY);return prefs().getFloat("schedule_"+day+"_"+(hour>=22?3:hour>=17?2:hour>=8?1:0),(float)base);}
 void tick(){if(busy)return;busy=true;try{
  if(!prefs().getBoolean("thermostatLive",false)){notifyStatus("Kontrol kapalı");stopSelf();return;}
  String host=prefs().getString("ip","100.35.15.71"),key=pref("key"),plug=pref("thermostatPlug"),sensor=pref("thermostatSensor");
  if(!host.matches("[0-9.]+")||key.isEmpty()||plug.isEmpty()||sensor.isEmpty()){notifyStatus("Yapılandırma eksik — kontrol yok");return;}
  String base="http://"+host+"/api/"+key+"/lights/"+plug;
  JSONObject light=new JSONObject(http(base,"GET",null,null));JSONObject state=light.optJSONObject("state");if(state==null)throw new IOException("Priz durumu okunamadı");boolean on=state.optBoolean("on");
  if(!haveState){lastKnownOn=on;haveState=true;lastChange=System.currentTimeMillis();}
  if(on!=lastKnownOn){lastKnownOn=on;lastChange=System.currentTimeMillis();}
  double temp=Double.NaN;String fault=null;
  try{JSONObject data=new JSONObject(http("https://api.smartthings.com/v1/devices/"+sensor+"/status","GET",null,token()));temp=temperature(data);if(Double.isNaN(temp)||temp<5||temp>40)fault="Geçersiz sıcaklık";}catch(Exception ex){fault="Sensör bağlantı hatası";}
  if(fault!=null){if(on)command(base,false);notifyStatus(fault+" · kapatma denendi");return;}
  double target=target();boolean desired=on?temp<target+.3:temp<=target-.3;
  if(desired!=on&&System.currentTimeMillis()-lastChange>=180000)command(base,desired);
  notifyStatus(String.format(Locale.forLanguageTag("tr-TR"),"Oda %.1f °C · Set %.1f °C · %s",temp,target,desired?"Isıtma talebi":"Bekleme"));
 }catch(Exception ex){notifyStatus("İletişim hatası: "+ex.getClass().getSimpleName()+" · priz durumu belirsiz");}finally{busy=false;}}
 void command(String base,boolean desired)throws Exception{JSONArray response=new JSONArray(http(base+"/state","PUT","{\"on\":"+desired+"}",null));for(int i=0;i<response.length();i++)if(response.optJSONObject(i)!=null&&response.optJSONObject(i).has("error"))throw new IOException("Hue komut hatası");JSONObject result=new JSONObject(http(base,"GET",null,null));JSONObject state=result.optJSONObject("state");if(state==null||state.optBoolean("on")!=desired)throw new IOException("Priz komutu doğrulanamadı");lastKnownOn=desired;lastChange=System.currentTimeMillis();prefs().edit().putLong("thermostatServiceLastChange",lastChange).apply();}
}
