package com.example.huecontrol;

import android.app.Activity;
import android.os.Bundle;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.view.MotionEvent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 final ExecutorService worker=Executors.newSingleThreadExecutor();
 final android.os.Handler refreshHandler=new android.os.Handler(android.os.Looper.getMainLooper()); boolean refreshing=false; long lastFeedback=0;
 long lastThermostatCommand=0; Boolean lastThermostatDemand=null; long lastSmartSuccess=0; volatile boolean thermostatCommandPending=false; long lastSmartRefresh=0; long lastWeatherRefresh=0; double outdoorTemp=Double.NaN; String weatherStatus="Dış hava bekleniyor"; long weatherUpdated=0; long lastSensorSample=0; final Runnable refreshTask=new Runnable(){public void run(){if(!key().isEmpty()&&!address().isEmpty()&&!editing)pollFeedback();if(!smartToken().isEmpty()&&System.currentTimeMillis()-lastSmartRefresh>=15000){lastSmartRefresh=System.currentTimeMillis();loadSmartThings(false);}if(!getPreferences(0).getBoolean("thermostatLive",false))thermostatTick();if(System.currentTimeMillis()-lastWeatherRefresh>=600000){lastWeatherRefresh=System.currentTimeMillis();loadWeather();if(getPreferences(0).getBoolean("thermostatLive",false))startThermostatService();}refreshHandler.postDelayed(this,3000);}};
 ScrollView mainScroll; int[] scrollPositions=new int[]{0,0}; LinearLayout shell, body, sidebar, cards, settingsPage; TextView status, connection; EditText ip;
 final ArrayList<Lamp> lamps=new ArrayList<>(); final ArrayList<Scene> scenes=new ArrayList<>(); final ArrayList<Room> rooms=new ArrayList<>(); boolean dark=true; int page=0;
 String selectedSceneRoom=""; final ArrayList<SmartSensor> smartSensors=new ArrayList<>(); boolean smartLoading=false; boolean editing=false; FrameLayout widgetCanvas; final LinkedHashMap<String,Widget> widgets=new LinkedHashMap<>();
 int accent(){return dark?0xffb69aff:0xff6945ca;}
 int good(){return dark?0xff63d8b0:0xff158766;}
 int border(){return dark?0xff303750:0xffe0e3ef;}
 int secondaryPanel(){return dark?0xff222940:0xfff0f1f8;}
 int lampTint(Lamp l){if(!l.on)return muted();if(l.color){float[] hsv={l.hue*360f/65535f,.65f,1f};return Color.HSVToColor(hsv);}return l.ct?0xffffc98b:0xffffdbaa;}
 int blendColor(int base,int tint,float ratio){float r=Math.max(0f,Math.min(1f,ratio));return Color.rgb(Math.round(Color.red(base)*(1-r)+Color.red(tint)*r),Math.round(Color.green(base)*(1-r)+Color.green(tint)*r),Math.round(Color.blue(base)*(1-r)+Color.blue(tint)*r));}
 int cardTint(int source){int strength=getPreferences(0).getInt("dynamicStrength",35);return blendColor(panel(),source,strength/100f);}
 int lampCardColor(Lamp l){if(!getPreferences(0).getBoolean("dynamicCards",true))return panel();return l.on?cardTint(l.plug?0xff48c59b:lampTint(l)):panel();}
 int airCardColor(SmartSensor s){double co2=numberCapability(s,"carbonDioxideMeasurement","carbonDioxide");double pm=pm25Number(s);int severity=0;if(co2>=1200||pm>=35)severity=2;else if(co2>=800||pm>=12)severity=1;return cardTint(severity==2?0xffe44d5b:severity==1?0xffe5ae45:0xff39b984);}
 String pm25(SmartSensor s){
  JSONObject components=s.status.optJSONObject("components");
  if(components==null)return "—";
  String[] caps={"dustSensor","fineDustSensor","particulateMatterSensor","particulateMatter25Measurement","pm25Measurement","airQualitySensor"};
  String[] attrs={"fineDustLevel","fineDust","pm25","pm2_5","pm2.5","particulateMatter25","particulateMatter2_5","particulateMatter2Point5","massConcentrationPm2_5","massConcentrationPm25"};
  Iterator<String> ids=components.keys();
  while(ids.hasNext()){
   JSONObject component=components.optJSONObject(ids.next());if(component==null)continue;
   for(String cap:caps){JSONObject obj=component.optJSONObject(cap);if(obj==null)continue;
    for(String attr:attrs){JSONObject field=obj.optJSONObject(attr);if(field!=null){Object value=field.opt("value");if(value!=null&&value!=JSONObject.NULL)return String.valueOf(value);}}
   }
   Iterator<String> capKeys=component.keys();while(capKeys.hasNext()){
    String capName=capKeys.next();JSONObject obj=component.optJSONObject(capName);if(obj==null)continue;
    Iterator<String> keys=obj.keys();while(keys.hasNext()){
     String name=keys.next();String normalized=name.toLowerCase(java.util.Locale.ROOT).replace("_","").replace(".","");
     if(normalized.equals("pm25")||normalized.equals("finedustlevel")||normalized.equals("particulatematter25")||normalized.equals("massconcentrationpm25")){
      JSONObject field=obj.optJSONObject(name);if(field!=null){Object value=field.opt("value");if(value!=null&&value!=JSONObject.NULL)return String.valueOf(value);}
     }
    }
   }
  }
  return "—";
 }
 double pm25Number(SmartSensor s){try{return Double.parseDouble(pm25(s).replace(",","."));}catch(Exception ignored){return -1;}}
 double numberCapability(SmartSensor s,String capability,String attribute){try{return Double.parseDouble(capability(s,capability,attribute).replace(",","."));}catch(Exception ignored){return -1;}}
 GradientDrawable stroke(int color,int radius,int line){GradientDrawable d=shape(color,radius);d.setStroke(dp(1),line);return d;}
 void tintText(TextView v,int color){v.setTextColor(color);}
 void applySwitch(Switch sw){sw.setThumbTintList(ColorStateList.valueOf(Color.WHITE));sw.setTrackTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{accent(),dark?0xff555e75:0xffb5bbca}));}
 void applySeek(SeekBar sb,int color){sb.setProgressTintList(ColorStateList.valueOf(color));sb.setThumbTintList(ColorStateList.valueOf(color));sb.setProgressBackgroundTintList(ColorStateList.valueOf(dark?0xff424a61:0xffd7dae5));}
 GradientDrawable rainbow(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xfffb657a,0xffffbd63,0xffd8e76a,0xff54d9b7,0xff5faaff,0xffad82ff,0xfffb657a});d.setCornerRadius(dp(20));return d;}
 void spectrum(SeekBar sb){sb.setProgressDrawable(rainbow());sb.setThumbTintList(ColorStateList.valueOf(Color.WHITE));}
 void elevation(View v){v.setElevation(dp(dark?0:2));}
 int bg(){return dark?0xff0d1120:0xfff5f6fa;} int panel(){return dark?0xff1b2236:Color.WHITE;} int fg(){return dark?0xfff5f5fb:0xff1c2335;} int muted(){return dark?0xff9ba6bf:0xff6b7488;}
 String pref(String k){return getPreferences(0).getString(k,"");}
 String address(){return getPreferences(0).getString("ip","100.35.15.71");} String key(){return pref("key");}
 int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 @Override public void onCreate(Bundle b){super.onCreate(b);dark=getPreferences(0).getBoolean("dark",true);render();refreshHandler.postDelayed(refreshTask,3000);if(!key().isEmpty()&&!address().isEmpty())load();if(!smartToken().isEmpty())loadSmartThings();loadWeather();}
 GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(fg());t.setTextSize(size);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));else t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));t.setIncludeFontPadding(false);return t;}
 void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
 void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
 TextView addText(LinearLayout p,String s,int size,boolean bold){TextView t=text(s,size,bold);p.addView(t);return t;}
 void button(LinearLayout p,String s,Runnable r){TextView t=text(s,14,true);t.setGravity(Gravity.CENTER);pad(t,15,13,15,13);t.setBackground(shape(accent(),12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);p.addView(t,lp);t.setOnClickListener(v->r.run());}
 boolean widgetGestureActive=false; TextView thermostatSetLabel=null; TextView thermostatSummaryLabel=null; TextView thermostatDetailLabel=null;
 void render(){
  if(widgetGestureActive)return;
  if(mainScroll!=null){scrollPositions[page]=mainScroll.getScrollY();}
  getWindow().setStatusBarColor(bg());getWindow().setNavigationBarColor(bg());getWindow().getDecorView().setSystemUiVisibility(dark?0:View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
  shell=new LinearLayout(this);shell.setOrientation(1);shell.setBackgroundColor(bg());setContentView(shell);
  int widthDp=getResources().getConfiguration().screenWidthDp;
  boolean wide=widthDp>=700;
  LinearLayout layout=new LinearLayout(this);layout.setOrientation(wide?0:1);shell.addView(layout,new LinearLayout.LayoutParams(-1,-1));
  sidebar=vertical();pad(sidebar,wide?22:18,wide?32:16,wide?22:18,wide?18:12);sidebar.setBackgroundColor(panel());
  if(wide)layout.addView(sidebar,new LinearLayout.LayoutParams(dp(widthDp>=1100?238:204),-1));else layout.addView(sidebar,new LinearLayout.LayoutParams(-1,-2));
  TextView logo=addText(sidebar,"◉  HUE CONTROL",wide?19:17,true);logo.setLetterSpacing(.035f);gap(sidebar,wide?35:12);
  if(wide){nav("⌂   Kontrol paneli",0);nav("⚙   Ayarlar",1);gap(sidebar,26);TextView info=addText(sidebar,key().isEmpty()?"○  Bridge bağlı değil":"●  Yerel Bridge",12,true);info.setTextColor(key().isEmpty()?muted():good());}
  else {LinearLayout tabs=new LinearLayout(this);sidebar.addView(tabs);tab(tabs,"⌂  Kontrol",0);tab(tabs,"⚙  Ayarlar",1);}
  ScrollView scroll=new ScrollView(this);mainScroll=scroll;scroll.setFillViewport(true);scroll.setClipToPadding(false);layout.addView(scroll,new LinearLayout.LayoutParams(wide?0:-1,wide?-1:0,1));
  body=vertical();pad(body,wide?30:18,wide?28:20,wide?30:18,35);scroll.addView(body);
  if(page==0)showDashboard();else showSettings();
  final int restore=scrollPositions[page];scroll.post(()->scroll.scrollTo(0,restore));
 }
 void nav(String name,int n){TextView t=text(name,15,page==n);pad(t,16,17,10,17);if(page==n){t.setBackground(shape(dark?0xff3a315d:0xffeae2ff,15));t.setTextColor(dark?0xffeee4ff:0xff5a38b6);}else t.setTextColor(muted());sidebar.addView(t);gap(sidebar,8);t.setOnClickListener(v->{scrollPositions[n]=0;page=n;render();});}
 void tab(LinearLayout p,String name,int n){TextView t=text(name,14,page==n);pad(t,16,10,16,10);if(page==n){t.setBackground(shape(dark?0xff3a315d:0xffeae2ff,11));t.setTextColor(accent());}p.addView(t);t.setOnClickListener(v->{scrollPositions[n]=0;page=n;render();});}

 void showGlobalControls(){
  LinearLayout panel=vertical();pad(panel,17,13,17,13);panel.setBackground(stroke(panel(),18,border()));body.addView(panel);
  TextView t=addText(panel,"Tüm aydınlatmalar · prizler hariç",15,true);gap(panel,6);
  TextView pct=addText(panel,"Genel parlaklık",12,false);pct.setTextColor(muted());SeekBar dim=new SeekBar(this);dim.setMax(254);dim.setProgress(180);applySeek(dim,accent());panel.addView(dim);dim.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){for(Lamp l:lamps)if(!l.plug)setLight(l.id,"{\"on\":true,\"bri\":"+Math.max(1,p)+"}");}});
  TextView color=addText(panel,"Renkli lambalar · ortak renk",12,false);color.setTextColor(muted());SeekBar hue=new SeekBar(this);hue.setMax(65535);spectrum(hue);panel.addView(hue);hue.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){for(Lamp l:lamps)if(!l.plug&&l.color)setLight(l.id,"{\"on\":true,\"hue\":"+p+",\"sat\":254}");}});
 }
 void pollFeedback(){if(refreshing)return;refreshing=true;worker.execute(()->{try{JSONObject data=new JSONObject(request(address(),"/api/"+key()+"/lights","GET",null));boolean changed=false;for(Lamp l:lamps){JSONObject o=data.optJSONObject(l.id);if(o==null)continue;JSONObject st=o.optJSONObject("state");if(st==null)continue;boolean on=st.optBoolean("on",l.on);int bri=st.optInt("bri",l.bri),hue=st.optInt("hue",l.hue),ct=st.optInt("ct",l.ctValue);if(l.on!=on||l.bri!=bri||l.hue!=hue||l.ctValue!=ct){l.on=on;l.bri=bri;l.hue=hue;l.ctValue=ct;changed=true;}}lastFeedback=System.currentTimeMillis();final boolean update=changed;runOnUiThread(()->{if(update&&!editing&&page==0)drawWidgets();});}catch(Exception e){/* A failed poll must not overwrite last known values. */}finally{refreshing=false;}});}

 void showDashboard(){
  LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);body.addView(header);
  LinearLayout headings=vertical();header.addView(headings,new LinearLayout.LayoutParams(0,-2,1));
  addText(headings,"Ev kontrol paneli",28,true);gap(headings,7);
  TextView conn=addText(headings,key().isEmpty()?"○  Bridge eşleştirilmedi":"●  Yerel Bridge  ·  "+lamps.size()+" cihaz  ·  Son veri: "+(lastFeedback==0?"bekleniyor":new java.text.SimpleDateFormat("HH:mm:ss",java.util.Locale.getDefault()).format(new java.util.Date(lastFeedback))),13,false);conn.setTextColor(key().isEmpty()?muted():good());
  TextView edit=text(editing?"✓  Tamam":"✎  Düzenle",13,true);pad(edit,15,12,15,12);edit.setBackground(stroke(editing?accent():panel(),13,editing?accent():border()));header.addView(edit);edit.setOnClickListener(v->{editing=!editing;render();});gap(body,24);
  LinearLayout actions=new LinearLayout(this);body.addView(actions);smallButton(actions,"☀  Tümünü aç",()->all(true));smallButton(actions,"☾  Tümünü kapat",()->all(false));gap(body,10);showGlobalControls();gap(body,18);
  if(editing){button(body,"＋  Widget ekle",()->chooseWidget());TextView hint=addText(body,"Kart başlığından taşı  ·  Sağ alt köşeden boyutlandır  ·  × ile kaldır",12,false);hint.setTextColor(muted());gap(body,18);}
  showScenes();showRooms();showClimate();showThermostat();showSmartSensors();LinearLayout row= new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);body.addView(row);
  TextView title=text("Aydınlatmalar ve prizler",19,true);row.addView(title,new LinearLayout.LayoutParams(0,-2,1));TextView count=text(lamps.size()+" cihaz",12,false);count.setTextColor(muted());row.addView(count);gap(body,15);
  widgetCanvas=new FrameLayout(this);widgetCanvas.setClipChildren(false);widgetCanvas.setClipToPadding(false);
  body.addView(widgetCanvas,new LinearLayout.LayoutParams(-1,dp(700)));
  ensureWidgets();final FrameLayout canvasAtCreation=widgetCanvas;canvasAtCreation.post(()->{if(widgetCanvas==canvasAtCreation&&!widgetGestureActive)drawWidgets();});
  status=addText(body,"",12,false);status.setTextColor(muted());
 }
 void smallButton(LinearLayout parent,String label,Runnable action){TextView t=text(label,13,true);t.setGravity(Gravity.CENTER);pad(t,14,11,14,11);t.setBackground(stroke(panel(),13,border()));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(3),0,dp(3),0);parent.addView(t,lp);t.setOnClickListener(v->action.run());}
 static class Widget {String id;int x,y,w,h;Widget(String id,int x,int y,int w,int h){this.id=id;this.x=x;this.y=y;this.w=w;this.h=h;}}
 String widgetPref(){return "widgets_v5_"+(getResources().getConfiguration().orientation==Configuration.ORIENTATION_PORTRAIT?"portrait":"landscape");}
 void saveWidgets(){JSONArray a=new JSONArray();for(Widget w:widgets.values()){JSONObject o=new JSONObject();try{o.put("id",w.id);o.put("x",w.x);o.put("y",w.y);o.put("w",w.w);o.put("h",w.h);a.put(o);}catch(Exception ignored){}}getPreferences(0).edit().putString(widgetPref(),a.toString()).apply();}
 void ensureWidgets(){if(!widgets.isEmpty())return;String saved=pref(widgetPref());if(!saved.isEmpty()){try{JSONArray a=new JSONArray(saved);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String id=o.getString("id");widgets.put(id,new Widget(id,o.optInt("x"),o.optInt("y"),o.optInt("w",280),o.optInt("h",260)));}if(a.length()>0||lamps.isEmpty())return;}catch(Exception ignored){}}
  // New orientation gets its own layout; portrait is stacked to prevent collisions.
  int col=0,row=0;int cols=getResources().getConfiguration().screenWidthDp>=1100?3:(getResources().getConfiguration().screenWidthDp>=650?2:1);for(Lamp l:lamps){widgets.put(l.id,new Widget(l.id,col*304,row*320,286,302));col++;if(col==cols){col=0;row++;}}}
 Lamp lamp(String id){for(Lamp l:lamps)if(l.id.equals(id))return l;return null;}
 SmartSensor sensorById(String id){for(SmartSensor sensor:smartSensors)if(sensor.id.equals(id))return sensor;return null;}
 void chooseWidget(){ArrayList<String> ids=new ArrayList<>(),names=new ArrayList<>();for(Lamp l:lamps)if(!widgets.containsKey(l.id)){ids.add(l.id);names.add("💡  "+l.name);}for(SmartSensor sensor:smartSensors)if(!widgets.containsKey("sensor:"+sensor.id)){ids.add("sensor:"+sensor.id);names.add("🌡  "+sensor.name);}if(ids.isEmpty()){message("Eklenebilecek cihaz yok.");return;}new android.app.AlertDialog.Builder(this).setTitle("Widget ekle · Hue / SmartThings").setItems(names.toArray(new String[0]),(d,which)->{String id=ids.get(which);int y=0;for(Widget w:widgets.values())y=Math.max(y,w.y+w.h+12);widgets.put(id,new Widget(id,0,y,286,id.startsWith("sensor:")?230:302));saveWidgets();drawWidgets();}).setNegativeButton("Vazgeç",null).show();}
 void drawSensorWidget(Widget w,SmartSensor sensor,int availableDp,boolean narrow,int index){w.w=Math.max(190,Math.min(w.w,availableDp));w.h=Math.max(210,w.h);if(narrow){w.x=0;w.y=index*(Math.max(302,w.h)+14);w.w=availableDp;}else w.x=Math.max(0,Math.min(w.x,availableDp-w.w));LinearLayout card=vertical();pad(card,18,16,18,12);card.setBackground(stroke(getPreferences(0).getBoolean("dynamicCards",true)?(sensor.motion?cardTint("active".equalsIgnoreCase(capability(sensor,"motionSensor","motion"))?0xff39b984:0xff6d7589):airCardColor(sensor)):panel(),20,editing?accent():border()));elevation(card);FrameLayout.LayoutParams pos=new FrameLayout.LayoutParams(dp(w.w),dp(w.h));pos.leftMargin=dp(w.x);pos.topMargin=dp(w.y);widgetCanvas.addView(card,pos);LinearLayout top=new LinearLayout(this);card.addView(top);TextView name=text(sensor.name,16,true);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));if(editing){TextView remove=text("×",22,true);top.addView(remove);remove.setOnClickListener(v->{widgets.remove(w.id);saveWidgets();drawWidgets();});attachDrag(name,card,w);}if(sensor.air){gap(card,10);addText(card,"🌡  "+capability(sensor,"temperatureMeasurement","temperature")+" °C  ·  Nem "+capability(sensor,"relativeHumidityMeasurement","humidity")+" %",15,false);addText(card,"CO₂ "+capability(sensor,"carbonDioxideMeasurement","carbonDioxide")+" ppm",14,false);addText(card,"PM2.5 "+pm25(sensor)+" µg/m³",14,false);}if(sensor.motion)addText(card,"Hareket: "+capability(sensor,"motionSensor","motion")+"  ·  Pil "+capability(sensor,"battery","battery")+"%",14,false);if(!editing){gap(card,10);TextView detail=addText(card,"24 saatlik grafikler  ›",13,true);detail.setTextColor(accent());card.setOnClickListener(v->showSensorDetails(sensor));}else{TextView handle=addText(card,"↘  Boyutlandır",11,true);handle.setGravity(Gravity.RIGHT);attachResize(handle,card,w);}}
 void drawWidgets(){if(widgetCanvas==null||widgetGestureActive)return;widgetCanvas.removeAllViews();float density=getResources().getDisplayMetrics().density;int available=Math.max(dp(190),widgetCanvas.getWidth());int availableDp=(int)(available/density);int maxBottom=350; boolean narrow=availableDp<610; int index=0;
  for(Widget w:widgets.values()){if(w.id.startsWith("sensor:")){SmartSensor sensor=sensorById(w.id.substring(7));if(sensor!=null){drawSensorWidget(w,sensor,availableDp,narrow,index);maxBottom=Math.max(maxBottom,w.y+w.h+20);index++;}continue;}Lamp l=lamp(w.id);if(l==null)continue;w.w=Math.max(190,Math.min(w.w,availableDp));w.h=Math.max(280,w.h);if(narrow){w.x=0;w.y=index*(Math.max(302,w.h)+14);w.w=availableDp;w.h=Math.max(302,w.h);}else{w.x=Math.max(0,Math.min(w.x,availableDp-w.w));}index++;
   LinearLayout card=vertical();pad(card,18,17,18,12);card.setBackground(stroke(lampCardColor(l),20,editing?accent():border()));elevation(card);
   FrameLayout.LayoutParams pos=new FrameLayout.LayoutParams(dp(w.w),dp(w.h));pos.leftMargin=dp(Math.max(0,Math.min(w.x,availableDp-w.w)));pos.topMargin=dp(Math.max(0,w.y));widgetCanvas.addView(card,pos);
   LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);card.addView(top);
   TextView dot=text("●",16,true);dot.setTextColor(lampTint(l));LinearLayout.LayoutParams dotp=new LinearLayout.LayoutParams(-2,-2);dotp.rightMargin=dp(9);top.addView(dot,dotp);
   TextView name=text(l.name,16,true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
   if(editing){TextView remove=text("×",23,true);pad(remove,9,0,5,0);top.addView(remove);remove.setOnClickListener(v->{widgets.remove(w.id);saveWidgets();drawWidgets();});attachDrag(name,card,w);attachDrag(dot,card,w);}
   else {Switch sw=new Switch(this);sw.setChecked(l.on);applySwitch(sw);top.addView(sw);sw.setOnCheckedChangeListener((v,on)->{l.on=on;dot.setTextColor(lampTint(l));setLight(l.id,"{\"on\":"+on+"}");});}
   gap(card,7);TextView subtitle=addText(card,(l.plug?"Akıllı priz · ":"Aydınlatma · ")+(l.on?"Açık":"Kapalı"),12,false);subtitle.setTextColor(muted());gap(card,10);
   if(!l.plug){LinearLayout dimHeader=new LinearLayout(this);card.addView(dimHeader);TextView label=text("Parlaklık",12,false);label.setTextColor(muted());dimHeader.addView(label,new LinearLayout.LayoutParams(0,-2,1));TextView pct=text(Math.round(l.bri*100f/254)+"%",12,true);dimHeader.addView(pct);
   SeekBar dim=new SeekBar(this);dim.setMax(254);dim.setProgress(l.bri);applySeek(dim,accent());card.addView(dim);dim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean user){if(user)pct.setText(Math.round(p*100f/254)+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){l.bri=Math.max(1,s.getProgress());setLight(l.id,"{\"on\":true,\"bri\":"+l.bri+"}");}});
   if(l.color){TextView hue=addText(card,"Renk tonu",12,false);hue.setTextColor(muted());SeekBar h=new SeekBar(this);h.setMax(65535);h.setProgress(l.hue);spectrum(h);card.addView(h);h.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){l.hue=p;dot.setTextColor(lampTint(l));setLight(l.id,"{\"on\":true,\"hue\":"+p+",\"sat\":254}");}});}
   if(l.ct){TextView ct=addText(card,"Beyaz sıcaklığı  ·  Sıcak — Soğuk",12,false);ct.setTextColor(muted());SeekBar temp=new SeekBar(this);temp.setMax(347);temp.setProgress(Math.max(0,Math.min(347,500-l.ctValue)));applySeek(temp,0xffffbc7e);card.addView(temp);temp.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){l.ctValue=500-p;setLight(l.id,"{\"on\":true,\"ct\":"+l.ctValue+"}");}});}
   }if(editing){TextView handle=text("↘  Boyutlandır",11,true);handle.setTextColor(accent());handle.setGravity(Gravity.RIGHT);card.addView(handle,new LinearLayout.LayoutParams(-1,-2));attachResize(handle,card,w);}
   maxBottom=Math.max(maxBottom,w.y+w.h+20);
  }
  widgetCanvas.getLayoutParams().height=dp(maxBottom);widgetCanvas.requestLayout();
 }
 void attachDrag(View grip,View card,Widget w){grip.setOnTouchListener(new View.OnTouchListener(){float downX,downY;int startX,startY;public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:widgetGestureActive=true;downX=e.getRawX();downY=e.getRawY();startX=w.x;startY=w.y;return true;case MotionEvent.ACTION_MOVE:int maxX=Math.max(0,(int)(widgetCanvas.getWidth()/getResources().getDisplayMetrics().density)-w.w);w.x=Math.max(0,Math.min(maxX,startX+(int)((e.getRawX()-downX)/getResources().getDisplayMetrics().density)));w.y=Math.max(0,startY+(int)((e.getRawY()-downY)/getResources().getDisplayMetrics().density));FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)card.getLayoutParams();p.leftMargin=dp(w.x);p.topMargin=dp(w.y);card.setLayoutParams(p);return true;case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:widgetGestureActive=false;saveWidgets();return true;}return false;}});}
 void attachResize(View grip,View card,Widget w){grip.setOnTouchListener(new View.OnTouchListener(){float downX,downY;int startW,startH;public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:widgetGestureActive=true;downX=e.getRawX();downY=e.getRawY();startW=w.w;startH=w.h;return true;case MotionEvent.ACTION_MOVE:int maxW=Math.max(190,(int)(widgetCanvas.getWidth()/getResources().getDisplayMetrics().density)-w.x);w.w=Math.max(190,Math.min(maxW,startW+(int)((e.getRawX()-downX)/getResources().getDisplayMetrics().density)));w.h=Math.max(210,Math.min(750,startH+(int)((e.getRawY()-downY)/getResources().getDisplayMetrics().density)));FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)card.getLayoutParams();p.width=dp(w.w);p.height=dp(w.h);card.setLayoutParams(p);return true;case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:widgetGestureActive=false;saveWidgets();return true;}return false;}});}
 void drawCards(){cards.removeAllViews();int width=getResources().getDisplayMetrics().widthPixels;int cols=getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE?(width>dp(1000)?3:2):1;
  LinearLayout line=null;for(int i=0;i<lamps.size();i++){if(i%cols==0){line=new LinearLayout(this);cards.addView(line,new LinearLayout.LayoutParams(-1,-2));}Lamp l=lamps.get(i);LinearLayout card=vertical();pad(card,17,17,17,16);card.setBackground(shape(lampCardColor(l),18));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.setMargins(dp(5),dp(5),dp(5),dp(7));line.addView(card,cp);
   LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);card.addView(top);TextView name=text(l.name,17,true);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));Switch sw=new Switch(this);sw.setChecked(l.on);top.addView(sw);sw.setOnCheckedChangeListener((v,on)->{l.on=on;setLight(l.id,"{\"on\":"+on+"}");});
   gap(card,12);TextView pct=addText(card,"Parlaklık  "+Math.round(l.bri*100f/254)+"%",13,false);pct.setTextColor(muted());SeekBar dim=new SeekBar(this);dim.setMax(254);dim.setProgress(l.bri);card.addView(dim);dim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean user){if(user)pct.setText("Parlaklık  "+Math.round(p*100f/254)+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){l.bri=Math.max(1,s.getProgress());setLight(l.id,"{\"on\":true,\"bri\":"+l.bri+"}");}});
   if(l.color){gap(card,7);TextView hue=addText(card,"Renk",13,false);hue.setTextColor(muted());SeekBar h=new SeekBar(this);h.setMax(65535);h.setProgress(l.hue);card.addView(h);h.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){l.hue=p;setLight(l.id,"{\"on\":true,\"hue\":"+p+",\"sat\":254}");}});}
   if(l.ct){gap(card,7);TextView ct=addText(card,"Beyaz sıcaklığı • Sıcak ↔ Soğuk",12,false);ct.setTextColor(muted());SeekBar temp=new SeekBar(this);temp.setMax(347);temp.setProgress(Math.max(0,Math.min(347,500-l.ctValue)));card.addView(temp);temp.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){l.ctValue=500-p;setLight(l.id,"{\"on\":true,\"ct\":"+l.ctValue+"}");}});}
  }
 }
 abstract class StopSeek implements SeekBar.OnSeekBarChangeListener{public void onProgressChanged(SeekBar s,int p,boolean u){}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){stopped(s.getProgress());}public abstract void stopped(int p);}
 void showSettings(){addText(body,"Ayarlar",28,true);gap(body,20);addText(body,"Bridge bağlantısı",19,true);gap(body,8);ip=new EditText(this);ip.setSingleLine(true);ip.setTextColor(fg());ip.setHintTextColor(muted());ip.setHint("Bridge yerel IP adresi");ip.setText(address());body.addView(ip);gap(body,10);
  button(body,"IP adresini kaydet",()->{String a=ip.getText().toString().trim();if(!validIp(a)){message("Geçerli IPv4 adresi girin.");return;}getPreferences(0).edit().putString("ip",a).apply();message("Bridge IP kaydedildi.");});
  button(body,"Bridge ile eşleştir",()->pair());button(body,"Lambaları yenile",()->load());
  status=addText(body,key().isEmpty()?"Bridge henüz eşleştirilmedi.":"Bridge anahtarı kayıtlı.",13,false);status.setTextColor(muted());gap(body,24);
  addText(body,"SmartThings sensörleri (deneysel)",19,true);gap(body,8);
  TextView explain=addText(body,"SmartThings Personal Access Token ile yalnızca sensör verilerini okur. Token telefonda Android Keystore ile şifrelenir. Üretim sürümünde OAuth bağlantısı kullanılmalıdır.",12,false);explain.setTextColor(muted());gap(body,8);
  EditText smartInput=new EditText(this);smartInput.setSingleLine(true);smartInput.setInputType(129);smartInput.setTextColor(fg());smartInput.setHintTextColor(muted());smartInput.setHint(smartToken().isEmpty()?"SmartThings tokenını bir kez girin":"Token güvenle kayıtlı • değiştirmek için yeni token girin");body.addView(smartInput);gap(body,8);
  button(body,"SmartThings'e bağlan / cihazları oku",()->{String token=smartInput.getText().toString().trim();if(!token.isEmpty()){try{saveSmartToken(token);}catch(Exception e){message("Token güvenli saklanamadı: "+e.getMessage());return;}}if(smartToken().isEmpty()){message("Önce token girin.");return;}loadSmartThings();});
  TextView dynamicTitle=addText(body,"Dinamik widget kartları",17,true);gap(body,9);
  Switch dynamicSwitch=new Switch(this);dynamicSwitch.setText("Kartın tamamını cihaz durumuna göre renklendir");dynamicSwitch.setTextColor(fg());dynamicSwitch.setChecked(getPreferences(0).getBoolean("dynamicCards",true));applySwitch(dynamicSwitch);body.addView(dynamicSwitch);dynamicSwitch.setOnCheckedChangeListener((v,checked)->{getPreferences(0).edit().putBoolean("dynamicCards",checked).apply();});
  TextView strengthLabel=addText(body,"Renk yoğunluğu: "+getPreferences(0).getInt("dynamicStrength",35)+"%",13,false);SeekBar strength=new SeekBar(this);strength.setMax(60);strength.setProgress(getPreferences(0).getInt("dynamicStrength",35));body.addView(strength);strength.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar bar,int value,boolean user){strengthLabel.setText("Renk yoğunluğu: "+value+"%");if(user)getPreferences(0).edit().putInt("dynamicStrength",value).apply();}public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}});
  gap(body,14);
  button(body,"SmartThings bağlantısını kaldır",()->{getPreferences(0).edit().remove("smartToken").apply();smartSensors.clear();message("SmartThings tokenı silindi.");});gap(body,18);
  addText(body,"Dış hava durumu",19,true);gap(body,8);
  TextView cityHint=addText(body,"Şehir adı (Open-Meteo; varsayılan İzmir). Konum izni gerekmez.",12,false);cityHint.setTextColor(muted());
  EditText cityInput=new EditText(this);cityInput.setSingleLine(true);cityInput.setTextColor(fg());cityInput.setHintTextColor(muted());cityInput.setHint("Şehir adı");cityInput.setText(pref("weatherCity").isEmpty()?"İzmir":pref("weatherCity"));body.addView(cityInput);
  button(body,"Şehri kaydet ve hava durumunu yenile",()->{String city=cityInput.getText().toString().trim();if(city.isEmpty()){message("Şehir adı girin.");return;}getPreferences(0).edit().putString("weatherCity",city).apply();lastWeatherRefresh=System.currentTimeMillis();loadWeather();});gap(body,20);
  addText(body,"Termostat",19,true);gap(body,8);button(body,"Termostat ayarları",()->editThermostat());addText(body,"Canlı kontrol yalnızca uygulama çalışırken aktiftir; bağlantı kaybında priz açık kalabilir.",12,false);button(body,"Haftalık sıcaklık programı",()->editSchedule());button(body,"Termostat çalışma geçmişi",()->showThermostatHistory());gap(body,16);addText(body,"Görünüm",19,true);Switch theme=new Switch(this);theme.setText("Koyu tema");theme.setTextColor(fg());theme.setTextSize(16);theme.setChecked(dark);body.addView(theme);theme.setOnCheckedChangeListener((v,on)->{dark=on;getPreferences(0).edit().putBoolean("dark",on).apply();render();});gap(body,24);
  addText(body,"Tüm lambalar ("+lamps.size()+")",19,true);gap(body,10);for(Lamp l:lamps){TextView t=addText(body,"• "+l.name+"   (ID: "+l.id+")",15,false);pad(t,5,9,5,9);}gap(body,20);addText(body,"Hue Control v11 · Termostat Programı ve Geçmiş",12,false);
 }
 boolean validIp(String a){if(!a.matches("\\d{1,3}(\\.\\d{1,3}){3}"))return false;for(String part:a.split("\\."))if(Integer.parseInt(part)>255)return false;return true;}
 void message(String m){runOnUiThread(()->{if(status!=null)status.setText(m);else Toast.makeText(this,m,Toast.LENGTH_LONG).show();});}
 String request(String host,String path,String method,String payload)throws Exception{if(!validIp(host))throw new Exception("Geçersiz IP");HttpURLConnection c=(HttpURLConnection)new URL("http://"+host+path).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);c.setRequestMethod(method);if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(payload.getBytes("UTF-8"));}}try(InputStream in=c.getResponseCode()<400?c.getInputStream():c.getErrorStream()){if(in==null)throw new Exception("HTTP "+c.getResponseCode());return new String(in.readAllBytes(),"UTF-8");}finally{c.disconnect();}}
 void pair(){String host=ip==null?address():ip.getText().toString().trim();if(!validIp(host)){message("Önce geçerli IP girin.");return;}getPreferences(0).edit().putString("ip",host).apply();message("Bridge düğmesine basın ve tekrar eşleştirmeyi deneyin.");worker.execute(()->{try{JSONArray a=new JSONArray(request(host,"/api","POST","{\"devicetype\":\"huecontrol#android\"}"));JSONObject o=a.getJSONObject(0);if(o.has("success")){String k=o.getJSONObject("success").getString("username");getPreferences(0).edit().putString("key",k).apply();message("Eşleştirme başarılı.");load();}else message("Bridge düğmesine basın: "+o.optJSONObject("error").optString("description","Eşleştirme bekleniyor"));}catch(Exception e){message("Bağlantı hatası: "+e.getMessage());}});}
 void load(){String host=address(),token=key();if(token.isEmpty()||host.isEmpty()){message("Önce Bridge ile eşleştirin.");return;}worker.execute(()->{try{JSONObject data=new JSONObject(request(host,"/api/"+token+"/lights","GET",null));ArrayList<Lamp> fresh=new ArrayList<>();Iterator<String> ids=data.keys();while(ids.hasNext()){String id=ids.next();JSONObject o=data.optJSONObject(id);if(o==null)continue;JSONObject st=o.optJSONObject("state");if(st==null)st=new JSONObject();JSONObject caps=o.optJSONObject("capabilities");JSONObject control=caps==null?null:caps.optJSONObject("control");Lamp l=new Lamp();l.id=id;l.name=o.optString("name","Lamba "+id);l.on=st.optBoolean("on");l.bri=st.optInt("bri",127);l.hue=st.optInt("hue",0);l.ctValue=st.optInt("ct",350);String type=o.optString("type","");l.plug=type.toLowerCase(java.util.Locale.ROOT).contains("on/off plug")||o.optString("modelid","").equalsIgnoreCase("LOM001")||o.optString("modelid","").equalsIgnoreCase("LOM002");l.color=st.has("hue")||type.contains("color light");l.ct=st.has("ct")||type.contains("temperature");if(control!=null&&control.has("ct"))l.ct=true;if(l.plug){l.color=false;l.ct=false;}fresh.add(l);}Collections.sort(fresh,(a,b)->a.name.compareToIgnoreCase(b.name));
   ArrayList<Scene> newScenes=new ArrayList<>();ArrayList<Room> newRooms=new ArrayList<>();
   try{JSONObject groups=new JSONObject(request(host,"/api/"+token+"/groups","GET",null));Iterator<String> gi=groups.keys();while(gi.hasNext()){String id=gi.next();JSONObject g=groups.optJSONObject(id);if(g==null||id.equals("0"))continue;Room room=new Room();room.id=id;room.name=g.optString("name","Oda");room.type=g.optString("type","");room.state=g.optJSONObject("action");newRooms.add(room);}}catch(Exception ignored){}
   try{JSONObject list=new JSONObject(request(host,"/api/"+token+"/scenes","GET",null));Iterator<String> si=list.keys();while(si.hasNext()){String id=si.next();JSONObject o=list.optJSONObject(id);if(o==null)continue;String group=o.optString("group","");if(group.isEmpty()||group.equals("0"))continue;Scene sc=new Scene();sc.id=id;sc.name=o.optString("name","Sahne");sc.group=group;newScenes.add(sc);}}catch(Exception ignored){}
   Collections.sort(newScenes,(a,b)->a.name.compareToIgnoreCase(b.name));
   LinkedHashMap<String,Scene> unique=new LinkedHashMap<>();for(Scene sc:newScenes){String k=sc.group+"|"+sc.name.toLowerCase(java.util.Locale.ROOT);if(!unique.containsKey(k))unique.put(k,sc);}newScenes.clear();newScenes.addAll(unique.values());
   runOnUiThread(()->{lamps.clear();lamps.addAll(fresh);scenes.clear();scenes.addAll(newScenes);rooms.clear();rooms.addAll(newRooms);widgets.clear();render();message(lamps.size()+" lamba, "+scenes.size()+" sahne yüklendi.");});}catch(Exception e){message("Okuma hatası: "+e.getMessage());}});}
 void setLight(String id,String payload){String host=address(),token=key();worker.execute(()->{try{String result=request(host,"/api/"+token+"/lights/"+id+"/state","PUT",payload);JSONArray a=new JSONArray(result);if(a.length()>0&&a.getJSONObject(0).has("error"))message("Hue hatası: "+a.getJSONObject(0).getJSONObject("error").optString("description"));}catch(Exception e){message("Kontrol hatası: "+e.getMessage());}});}
 static class Scene{String id,name,group;}
 static class Room{String id,name,type;JSONObject state;}
 void activateScene(Scene sc){String host=address(),token=key();worker.execute(()->{try{JSONArray response=new JSONArray(request(host,"/api/"+token+"/groups/"+sc.group+"/action","PUT","{\"scene\":\""+sc.id+"\"}"));if(response.length()>0&&response.getJSONObject(0).has("error"))message("Sahne hatası: "+response.getJSONObject(0).getJSONObject("error").optString("description"));else{message(sc.name+" sahnesi etkinleştirildi.");}}catch(Exception e){message("Sahne hatası: "+e.getMessage());}});}
 void setGroupBrightness(String id,int bri){worker.execute(()->{try{request(address(),"/api/"+key()+"/groups/"+id+"/action","PUT","{\"on\":true,\"bri\":"+Math.max(1,bri)+"}");}catch(Exception e){message("Oda dim hatası: "+e.getMessage());}});}
 void setRoom(Room room,boolean on){String host=address(),token=key();worker.execute(()->{try{request(host,"/api/"+token+"/groups/"+room.id+"/action","PUT","{\"on\":"+on+"}");message(room.name+" güncellendi.");}catch(Exception e){message("Oda kontrol hatası: "+e.getMessage());}});}
 void showScenes(){if(scenes.isEmpty())return;addText(body,"Görünümlerim",19,true);gap(body,10);
  LinkedHashMap<String,String> choices=new LinkedHashMap<>();for(Room r:rooms)choices.put(r.id,r.name);
  if(selectedSceneRoom.isEmpty()||!choices.containsKey(selectedSceneRoom)){for(Scene sc:scenes)if(choices.containsKey(sc.group)){selectedSceneRoom=sc.group;break;}}
  HorizontalScrollView filters=new HorizontalScrollView(this);filters.setHorizontalScrollBarEnabled(false);body.addView(filters);LinearLayout filterRow=new LinearLayout(this);filters.addView(filterRow);
  for(Map.Entry<String,String> entry:choices.entrySet()){boolean active=entry.getKey().equals(selectedSceneRoom);TextView chip=text(entry.getValue(),13,active);pad(chip,14,9,14,9);chip.setTextColor(active?fg():muted());chip.setBackground(stroke(active?secondaryPanel():panel(),13,active?accent():border()));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);cp.rightMargin=dp(8);filterRow.addView(chip,cp);chip.setOnClickListener(v->{selectedSceneRoom=entry.getKey();render();});}gap(body,12);
  HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);body.addView(scroll);LinearLayout row=new LinearLayout(this);scroll.addView(row);int count=0;
  HashSet<String> names=new HashSet<>();for(Scene sc:scenes){if(!sc.group.equals(selectedSceneRoom))continue;String dedup=sc.name.trim().toLowerCase(java.util.Locale.ROOT);if(!names.add(dedup))continue;count++;LinearLayout tile=vertical();tile.setGravity(Gravity.CENTER);pad(tile,14,16,14,16);tile.setBackground(stroke(panel(),18,border()));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(146),dp(114));lp.rightMargin=dp(12);row.addView(tile,lp);TextView symbol=addText(tile,"✦",27,true);symbol.setGravity(Gravity.CENTER);symbol.setTextColor(accent());gap(tile,8);TextView label=addText(tile,sc.name,13,true);label.setGravity(Gravity.CENTER);label.setMaxLines(2);tile.setOnClickListener(v->activateScene(sc));}
  if(count==0){TextView empty=addText(row,"Bu oda için sahne bulunamadı.",13,false);empty.setTextColor(muted());}gap(body,24);
 }
 void showRooms(){if(rooms.isEmpty())return;addText(body,"Odalar ve bölgeler",19,true);gap(body,10);HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);body.addView(scroll);LinearLayout row=new LinearLayout(this);scroll.addView(row);for(Room room:rooms){LinearLayout tile=vertical();pad(tile,14,12,14,12);tile.setBackground(stroke(panel(),16,border()));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(188),-2);lp.rightMargin=dp(12);row.addView(tile,lp);addText(tile,room.name,14,true);gap(tile,8);LinearLayout actions=new LinearLayout(this);tile.addView(actions);smallButton(actions,"Aç",()->setRoom(room,true));smallButton(actions,"Kapat",()->setRoom(room,false));TextView value=addText(tile,"Parlaklık",12,false);value.setTextColor(muted());SeekBar slider=new SeekBar(this);slider.setMax(254);slider.setProgress(room.state==null?127:room.state.optInt("bri",127));applySeek(slider,accent());tile.addView(slider);slider.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){setGroupBrightness(room.id,p);}});}gap(body,24);}

 static class SmartSensor{String id,name;JSONObject status;boolean motion,air;}
 String smartToken(){try{String value=pref("smartToken");if(value.isEmpty())return "";byte[] all=android.util.Base64.decode(value,android.util.Base64.NO_WRAP);byte[] iv=java.util.Arrays.copyOfRange(all,0,12);byte[] encrypted=java.util.Arrays.copyOfRange(all,12,all.length);javax.crypto.Cipher c=javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");java.security.KeyStore ks=java.security.KeyStore.getInstance("AndroidKeyStore");ks.load(null);java.security.Key k=ks.getKey("huecontrol_smart",null);c.init(javax.crypto.Cipher.DECRYPT_MODE,k,new javax.crypto.spec.GCMParameterSpec(128,iv));return new String(c.doFinal(encrypted),"UTF-8");}catch(Exception e){return "";}}
 void saveSmartToken(String token)throws Exception{java.security.KeyStore ks=java.security.KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("huecontrol_smart")){javax.crypto.KeyGenerator kg=javax.crypto.KeyGenerator.getInstance("AES","AndroidKeyStore");kg.init(new android.security.keystore.KeyGenParameterSpec.Builder("huecontrol_smart",android.security.keystore.KeyProperties.PURPOSE_ENCRYPT|android.security.keystore.KeyProperties.PURPOSE_DECRYPT).setBlockModes("GCM").setEncryptionPaddings("NoPadding").build());kg.generateKey();}javax.crypto.Cipher c=javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");c.init(javax.crypto.Cipher.ENCRYPT_MODE,ks.getKey("huecontrol_smart",null));byte[] iv=c.getIV(),encrypted=c.doFinal(token.getBytes("UTF-8")),both=new byte[iv.length+encrypted.length];System.arraycopy(iv,0,both,0,iv.length);System.arraycopy(encrypted,0,both,iv.length,encrypted.length);getPreferences(0).edit().putString("smartToken",android.util.Base64.encodeToString(both,android.util.Base64.NO_WRAP)).apply();}
 String smartRequest(String path,String token)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL("https://api.smartthings.com/v1/"+path).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Accept","application/json");try{int status=c.getResponseCode();InputStream in=status<400?c.getInputStream():c.getErrorStream();String data=in==null?"":new String(in.readAllBytes(),"UTF-8");if(status>=400)throw new Exception("SmartThings HTTP "+status);return data;}finally{c.disconnect();}}
 void loadSmartThings(){loadSmartThings(true);}
 void loadSmartThings(boolean notify){if(smartLoading)return;String token=smartToken();if(token.isEmpty())return;smartLoading=true;worker.execute(()->{try{JSONObject root=new JSONObject(smartRequest("devices",token));JSONArray items=root.optJSONArray("items");ArrayList<SmartSensor> found=new ArrayList<>();if(items!=null)for(int i=0;i<items.length();i++){JSONObject item=items.optJSONObject(i);if(item==null)continue;String id=item.optString("deviceId");if(id.isEmpty())continue;JSONObject state=new JSONObject(smartRequest("devices/"+id+"/status",token));String lower=(item.optString("label")+" "+item.optString("name")).toLowerCase(java.util.Locale.ROOT);String raw=state.toString();boolean motion=raw.contains("motionSensor"),air=raw.contains("carbonDioxideMeasurement")||raw.contains("dustSensor")||raw.contains("temperatureMeasurement")||raw.contains("relativeHumidityMeasurement");if(!motion&&!air)continue;SmartSensor sensor=new SmartSensor();sensor.id=id;sensor.name=item.optString("label",item.optString("name","Sensör"));sensor.status=state;sensor.motion=motion;sensor.air=air;found.add(sensor);}runOnUiThread(()->{smartSensors.clear();smartSensors.addAll(found);lastSmartSuccess=System.currentTimeMillis();recordSensorHistory(found);if(page==0&&!editing&&!widgetGestureActive)render();if(notify)message("SmartThings: "+found.size()+" sensör bulundu.");});}catch(Exception e){if(notify)message("SmartThings: "+e.getMessage());}finally{smartLoading=false;}});}
 String capability(SmartSensor s,String cap,String attr){JSONObject components=s.status.optJSONObject("components");JSONObject main=components==null?null:components.optJSONObject("main");JSONObject capability=main==null?null:main.optJSONObject(cap);JSONObject field=capability==null?null:capability.optJSONObject(attr);if(field==null)return "—";Object v=field.opt("value");return v==null||v==JSONObject.NULL?"—":String.valueOf(v);}
 void showSmartSensors(){if(smartSensors.isEmpty())return;addText(body,"SmartThings · Ev sensörleri",19,true);gap(body,12);for(SmartSensor s:smartSensors){LinearLayout card=vertical();pad(card,18,16,18,16);card.setBackground(stroke(getPreferences(0).getBoolean("dynamicCards",true)?(s.motion?cardTint("active".equalsIgnoreCase(capability(s,"motionSensor","motion"))?0xff39b984:0xff6d7589):airCardColor(s)):panel(),18,border()));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(12);body.addView(card,lp);addText(card,s.name,17,true);gap(card,8);if(s.motion){addText(card,"Hareket: "+capability(s,"motionSensor","motion"),15,false);addText(card,"Pil: "+capability(s,"battery","battery")+" %",13,false);}if(s.air){addText(card,"Sıcaklık: "+capability(s,"temperatureMeasurement","temperature")+" °C",14,false);addText(card,"Nem: "+capability(s,"relativeHumidityMeasurement","humidity")+" %",14,false);addText(card,"CO₂: "+capability(s,"carbonDioxideMeasurement","carbonDioxide")+" ppm",14,false);addText(card,"PM2.5: "+pm25(s)+" µg/m³",14,false);TextView detail=addText(card,"24 saatlik grafikler ve detaylar  ›",13,true);detail.setTextColor(accent());card.setOnClickListener(v->showSensorDetails(s));}else{card.setOnClickListener(v->showSensorDetails(s));}}}

 void loadWeather(){String city=pref("weatherCity");if(city.isEmpty())city="İzmir";final String query=city;worker.execute(()->{try{
  String geo=downloadJson("https://geocoding-api.open-meteo.com/v1/search?name="+java.net.URLEncoder.encode(query,"UTF-8")+"&count=1&language=tr&format=json");
  JSONArray results=new JSONObject(geo).optJSONArray("results");if(results==null||results.length()==0)throw new Exception("Şehir bulunamadı: "+query);
  JSONObject place=results.getJSONObject(0);double lat=place.getDouble("latitude"),lon=place.getDouble("longitude");
  String weather=downloadJson("https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&current=temperature_2m,relative_humidity_2m&timezone=auto");
  JSONObject current=new JSONObject(weather).getJSONObject("current");double t=current.getDouble("temperature_2m");
  runOnUiThread(()->{outdoorTemp=t;weatherStatus=place.optString("name",query);weatherUpdated=System.currentTimeMillis();if(page==0&&!editing&&!widgetGestureActive)render();});
 }catch(Exception e){runOnUiThread(()->{weatherStatus="Hava durumu alınamadı";if(page==0&&!editing&&!widgetGestureActive)render();});}});}
 String downloadJson(String uri)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(uri).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);try{int code=c.getResponseCode();if(code>=400)throw new IOException("HTTP "+code);try(InputStream in=c.getInputStream()){return new String(in.readAllBytes(),"UTF-8");}}finally{c.disconnect();}}

 double thermostatSet(){return getPreferences(0).getFloat("thermostatSet",23f);}
 SmartSensor thermostatSensor(){String id=pref("thermostatSensor");for(SmartSensor x:smartSensors)if(x.air&&x.id.equals(id))return x;for(SmartSensor x:smartSensors)if(x.air&&numberCapability(x,"temperatureMeasurement","temperature")>=0)return x;return null;}
 void startThermostatService(){try{android.content.Intent i=new android.content.Intent(this,ThermostatService.class);if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}catch(Exception e){message("Termostat servisi başlatılamadı: "+e.getMessage());}}
 void thermostatTick(){
  if(!getPreferences(0).getBoolean("thermostatLive",false))return;
  String plugId=pref("thermostatPlug");
  Lamp plug=null;for(Lamp l:lamps)if(l.plug&&l.id.equals(plugId)){plug=l;break;}
  if(plug==null||key().isEmpty())return;
  SmartSensor source=thermostatSensor();
  double temp=source==null?Double.NaN:numberCapability(source,"temperatureMeasurement","temperature");
  long now=System.currentTimeMillis();
  // Fail closed on stale data, but a dead tablet/network cannot guarantee a physical OFF.
  if(now-lastSmartSuccess>90000||Double.isNaN(temp)||temp<5||temp>40){if(plug.on)thermostatCommand(plug,false);return;}
  double target=effectiveThermostatSet();
  boolean demand=plug.on?temp<target+.3:temp<=target-.3;
  if(lastThermostatCommand>0&&now-lastThermostatCommand<180000)return;
  if(demand!=plug.on)thermostatCommand(plug,demand);
 }
 void thermostatCommand(Lamp plug,boolean on){
  if(thermostatCommandPending)return;
  thermostatCommandPending=true;
  final String id=plug.id;final boolean desired=on;
  worker.execute(()->{
   try{
    JSONArray response=new JSONArray(request(address(),"/api/"+key()+"/lights/"+id+"/state","PUT","{\"on\":"+desired+"}"));
    for(int i=0;i<response.length();i++)if(response.optJSONObject(i)!=null&&response.optJSONObject(i).has("error"))throw new Exception(response.getJSONObject(i).getJSONObject("error").optString("description"));
    JSONObject state=new JSONObject(request(address(),"/api/"+key()+"/lights/"+id,"GET",null)).optJSONObject("state");
    if(state==null||state.optBoolean("on")!=desired)throw new Exception("Priz durumu doğrulanamadı");
    runOnUiThread(()->{lastThermostatCommand=System.currentTimeMillis();lastThermostatDemand=desired;plug.on=desired;logThermostatEvent(desired);if(page==0&&!editing&&!widgetGestureActive)render();});
   }catch(Exception e){message("Termostat priz kontrol hatası: "+e.getMessage());}
   finally{thermostatCommandPending=false;}
  });
 }
 double effectiveThermostatSet(){
  SharedPreferences prefs=getPreferences(0);
  if(!prefs.getBoolean("scheduleEnabled",false))return thermostatSet();
  Calendar c=Calendar.getInstance();int day=(c.get(Calendar.DAY_OF_WEEK)+5)%7;int hour=c.get(Calendar.HOUR_OF_DAY);
  String key="schedule_"+day+"_"+(hour>=22?3:hour>=17?2:hour>=8?1:0);
  return prefs.getFloat(key,(float)thermostatSet());
 }
 void editSchedule(){
  LinearLayout layout=vertical();pad(layout,18,12,18,12);
  ScrollView scroll=new ScrollView(this);scroll.addView(layout);
  Switch enabled=new Switch(this);enabled.setText("Haftalık program aktif");enabled.setChecked(getPreferences(0).getBoolean("scheduleEnabled",false));layout.addView(enabled);
  addText(layout,"Zaman dilimleri: 00–08 / 08–17 / 17–22 / 22–24. Her gün için set sıcaklığı girin.",13,false);
  String[] days={"Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi","Pazar"};
  EditText[][] fields=new EditText[7][4];
  for(int d=0;d<7;d++){gap(layout,10);addText(layout,days[d],16,true);LinearLayout row=new LinearLayout(this);layout.addView(row);
   for(int t=0;t<4;t++){EditText field=new EditText(this);field.setSingleLine(true);field.setTextSize(12);field.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);field.setText(String.format(Locale.US,"%.1f",getPreferences(0).getFloat("schedule_"+d+"_"+t,(float)thermostatSet())));row.addView(field,new LinearLayout.LayoutParams(0,dp(54),1));fields[d][t]=field;}
  }
  new android.app.AlertDialog.Builder(this).setTitle("Haftalık sıcaklık programı").setView(scroll).setNegativeButton("Vazgeç",null).setPositiveButton("Kaydet",(dialog,which)->{
   try{float[][] values=new float[7][4];for(int d=0;d<7;d++)for(int t=0;t<4;t++){float v=Float.parseFloat(fields[d][t].getText().toString().replace(',','.'));if(v<15||v>30)throw new IllegalArgumentException();values[d][t]=v;}
    SharedPreferences.Editor edit=getPreferences(0).edit().putBoolean("scheduleEnabled",enabled.isChecked());for(int d=0;d<7;d++)for(int t=0;t<4;t++)edit.putFloat("schedule_"+d+"_"+t,values[d][t]);edit.apply();render();
   }catch(Exception e){message("Program sıcaklıkları 15–30 °C arasında olmalı.");}
  }).show();
 }
 void logThermostatEvent(boolean on){
  try{SharedPreferences p=getPreferences(0);JSONArray a=new JSONArray(p.getString("thermostatHistory","[]"));JSONObject entry=new JSONObject();entry.put("at",System.currentTimeMillis());entry.put("on",on);a.put(entry);
   JSONArray trimmed=new JSONArray();for(int i=Math.max(0,a.length()-1000);i<a.length();i++)trimmed.put(a.getJSONObject(i));p.edit().putString("thermostatHistory",trimmed.toString()).apply();
  }catch(Exception ignored){}
 }
 void showThermostatHistory(){
  LinearLayout content=vertical();pad(content,20,14,20,14);long now=System.currentTimeMillis();long since=now-86400000L;
  try{JSONArray a=new JSONArray(getPreferences(0).getString("thermostatHistory","[]"));long running=0;long start=-1;boolean last=false;
   for(int i=0;i<a.length();i++){JSONObject e=a.getJSONObject(i);long at=e.optLong("at");boolean on=e.optBoolean("on");if(at<=since){last=on;continue;}if(start<0){start=since;}if(last)running+=Math.max(0,at-start);start=at;last=on;}
   if(start>=0&&last)running+=now-start;
   addText(content,"Son 24 saatte kayıtlı açık kalma süresi: "+(running/3600000)+" sa "+((running/60000)%60)+" dk",16,true);
   addText(content,"Bu hesap yalnızca uygulamanın doğruladığı komutları temel alır; gerçek kombi çalışma süresi değildir.",12,false);gap(content,12);
   java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("dd.MM HH:mm",Locale.getDefault());for(int i=a.length()-1;i>=Math.max(0,a.length()-35);i--){JSONObject e=a.getJSONObject(i);addText(content,fmt.format(new Date(e.optLong("at")))+"  ·  Priz "+(e.optBoolean("on")?"AÇILDI":"KAPANDI"),13,false);gap(content,5);}
  }catch(Exception e){addText(content,"Geçmiş okunamadı",14,false);}
  ScrollView scroll=new ScrollView(this);scroll.addView(content);new android.app.AlertDialog.Builder(this).setTitle("Termostat olay geçmişi").setView(scroll).setPositiveButton("Kapat",null).show();
 }
 void showThermostat(){
  SmartSensor source=thermostatSensor();double temp=source==null?Double.NaN:numberCapability(source,"temperatureMeasurement","temperature");
  double target=effectiveThermostatSet();boolean enabled=getPreferences(0).getBoolean("thermostatLive",false);
  LinearLayout card=vertical();pad(card,18,16,18,16);card.setBackground(stroke(!enabled?panel():cardTint(Double.isNaN(temp)?0xff778899:temp<target-.3?0xffdc7545:0xff527eaa),20,border()));
  LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(16);body.addView(card,lp);
  addText(card,"♨  Kombi termostatı   ›",19,true);gap(card,10);
  thermostatSummaryLabel=addText(card,"Oda: "+(Double.isNaN(temp)?"—":String.format(Locale.US,"%.1f °C",temp))+"     Hedef: "+String.format(Locale.US,"%.1f °C",target),18,true);
  addText(card,!enabled?"Kontrol kapalı":Double.isNaN(temp)?"Sıcaklık okunamadı":temp<target-.3?"Isıtma talebi":"Beklemede",13,false);
  addText(card,"Kaynak: "+(source==null?"Sensör seçilmedi":source.name),12,false);gap(card,12);
  LinearLayout controls=new LinearLayout(this);card.addView(controls);
  TextView minus=text("−  0,5°",17,true);minus.setGravity(Gravity.CENTER);pad(minus,8,14,8,14);minus.setBackground(stroke(panel(),12,border()));controls.addView(minus,new LinearLayout.LayoutParams(0,-2,1));
  TextView set=text(String.format(Locale.US,"%.1f °C",thermostatSet()),20,true);thermostatSetLabel=set;set.setGravity(Gravity.CENTER);controls.addView(set,new LinearLayout.LayoutParams(0,-2,2));
  TextView plus=text("+  0,5°",17,true);plus.setGravity(Gravity.CENTER);pad(plus,8,14,8,14);plus.setBackground(stroke(panel(),12,border()));controls.addView(plus,new LinearLayout.LayoutParams(0,-2,1));
  minus.setOnClickListener(v->changeThermostat(-.5f));plus.setOnClickListener(v->changeThermostat(.5f));
  set.setOnClickListener(v->showSetpointInput());
  gap(card,10);TextView more=addText(card,"Grafikler · ±0,3 °C · Haftalık program · Çalışma geçmişi   ›",13,true);more.setTextColor(accent());
  more.setOnClickListener(v->showThermostatDetails());
  // Card surface opens details; buttons and setpoint have their own click handlers.
  card.setOnClickListener(v->showThermostatDetails());
 }
 void showSetpointInput(){
  EditText input=new EditText(this);input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);input.setSingleLine(true);input.setText(String.format(Locale.US,"%.1f",thermostatSet()));
  new android.app.AlertDialog.Builder(this).setTitle("Sıcaklık set değeri (15–30 °C)").setView(input).setNegativeButton("Vazgeç",null).setPositiveButton("Kaydet",(d,w)->{try{float val=Float.parseFloat(input.getText().toString().replace(',','.'));if(val<15||val>30){message("15–30 °C aralığında olmalı");return;}getPreferences(0).edit().putFloat("thermostatSet",val).apply();updateThermostatSetLabels();}catch(Exception e){message("Geçersiz sıcaklık");}}).show();
 }
 void showThermostatDetails(){
  LinearLayout content=vertical();pad(content,16,14,16,14);
  addText(content,"Kombi termostatı · Detaylar",21,true);gap(content,8);
  SmartSensor source=thermostatSensor();double temp=source==null?Double.NaN:numberCapability(source,"temperatureMeasurement","temperature");
  thermostatDetailLabel=addText(content,"Oda: "+(Double.isNaN(temp)?"—":String.format(Locale.US,"%.1f °C",temp))+"    Set: "+String.format(Locale.US,"%.1f °C",effectiveThermostatSet()),18,true);
  addText(content,"Kontrol bandı: ±0,3 °C · Minimum komut aralığı: 3 dk",13,false);gap(content,12);
  button(content,"Set sıcaklığını değiştir",()->showSetpointInput());
  if(source!=null){try{JSONArray a=new JSONArray(pref("history_"+source.id));if(a.length()>=2){addText(content,"Oda sıcaklığı · Son 24 saat",16,true);content.addView(new HistoryView(a,"temperature"),new LinearLayout.LayoutParams(-1,dp(200)));gap(content,12);}}catch(Exception ignored){}}
  addText(content,"Haftalık sıcaklık programı",17,true);gap(content,5);
  String[] days={"Pzt","Sal","Çar","Per","Cum","Cmt","Paz"};String[] slots={"00–08","08–17","17–22","22–24"};
  addText(content,"Zaman dilimleri: "+android.text.TextUtils.join(" / ",slots),12,false);
  for(int d=0;d<7;d++){StringBuilder row=new StringBuilder(days[d]+"   ");for(int t=0;t<4;t++)row.append(String.format(Locale.US,"%.1f°",getPreferences(0).getFloat("schedule_"+d+"_"+t,(float)thermostatSet()))).append("   ");addText(content,row.toString(),12,false);gap(content,4);}
  button(content,"Haftalık programı düzenle",()->editSchedule());
  addText(content,"Isıtma çalışma geçmişi",17,true);gap(content,6);
  try{JSONArray a=new JSONArray(getPreferences(0).getString("thermostatHistory","[]"));long now=System.currentTimeMillis(),since=now-86400000L;long running=0,start=since;boolean on=false;for(int i=0;i<a.length();i++){JSONObject event=a.optJSONObject(i);if(event==null)continue;long at=event.optLong("at");boolean next=event.optBoolean("on");if(at<=since){on=next;continue;}if(on)running+=Math.max(0,at-start);start=at;on=next;}if(on)running+=Math.max(0,now-start);
   addText(content,"Son 24 saatte tahmini açık: "+running/3600000+" sa "+(running/60000)%60+" dk",14,true);
   java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("dd.MM HH:mm",Locale.getDefault());for(int i=a.length()-1;i>=Math.max(0,a.length()-12);i--){JSONObject e=a.optJSONObject(i);if(e!=null)addText(content,fmt.format(new Date(e.optLong("at")))+"  "+(e.optBoolean("on")?"Açıldı":"Kapandı"),12,false);}
  }catch(Exception ignored){}
  button(content,"Tüm çalışma geçmişi",()->showThermostatHistory());button(content,"Termostat cihaz ve mod ayarları",()->editThermostat());
  addText(content,"Çalışma geçmişi doğrulanmış priz komutlarını gösterir; gerçek kombi yanma süresi değildir.",12,false);
  ScrollView scroll=new ScrollView(this);scroll.addView(content);new android.app.AlertDialog.Builder(this).setView(scroll).setPositiveButton("Kapat",null).show();
 }
 void updateThermostatSetLabels(){
  float set= (float)thermostatSet();
  if(thermostatSetLabel!=null)thermostatSetLabel.setText(String.format(Locale.US,"%.1f °C",set));
  SmartSensor source=thermostatSensor();double temp=source==null?Double.NaN:numberCapability(source,"temperatureMeasurement","temperature");
  String room=Double.isNaN(temp)?"—":String.format(Locale.US,"%.1f °C",temp);
  if(thermostatSummaryLabel!=null)thermostatSummaryLabel.setText("Oda: "+room+"     Hedef: "+String.format(Locale.US,"%.1f °C",effectiveThermostatSet()));
  if(thermostatDetailLabel!=null)thermostatDetailLabel.setText("Oda: "+room+"    Set: "+String.format(Locale.US,"%.1f °C",effectiveThermostatSet()));
 }
 void changeThermostat(float delta){float value=(float)Math.max(15,Math.min(30,thermostatSet()+delta));getPreferences(0).edit().putFloat("thermostatSet",value).apply();updateThermostatSetLabels();}
 void editThermostat(){
  LinearLayout content=vertical();pad(content,18,10,18,10);addText(content,"Sıcaklık set değeri (15–30 °C)",16,true);
  EditText input=new EditText(this);input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);input.setText(String.format(java.util.Locale.US,"%.1f",thermostatSet()));content.addView(input);
  Switch enabled=new Switch(this);enabled.setText("CANLI KONTROL (Hue prizine komut gönderir)");enabled.setChecked(getPreferences(0).getBoolean("thermostatLive",false));content.addView(enabled);
  ArrayList<SmartSensor> sensors=new ArrayList<>();ArrayList<String> labels=new ArrayList<>();for(SmartSensor x:smartSensors)if(x.air){sensors.add(x);labels.add(x.name);}
  android.widget.Spinner spinner=new android.widget.Spinner(this);
  if(!sensors.isEmpty()){spinner.setAdapter(new android.widget.ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels));String current=pref("thermostatSensor");for(int i=0;i<sensors.size();i++)if(sensors.get(i).id.equals(current))spinner.setSelection(i);addText(content,"Sıcaklık kaynağı",14,true);content.addView(spinner);}
  ArrayList<Lamp> plugs=new ArrayList<>();ArrayList<String> plugLabels=new ArrayList<>();for(Lamp l:lamps)if(l.plug){plugs.add(l);plugLabels.add(l.name);}
  android.widget.Spinner plugSpinner=new android.widget.Spinner(this);
  if(!plugs.isEmpty()){plugSpinner.setAdapter(new android.widget.ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,plugLabels));String currentPlug=pref("thermostatPlug");for(int i=0;i<plugs.size();i++)if(plugs.get(i).id.equals(currentPlug))plugSpinner.setSelection(i);addText(content,"Kombi kontrol prizi",14,true);content.addView(plugSpinner);}
  addText(content,"Canlı kontrol ön plan servisinde sürer. Tablet kapanırsa, servis öldürülürse veya ağ koparsa priz açık kalabilir. Bağımsız donanımsal watchdog gerekir.",12,false);
  new android.app.AlertDialog.Builder(this).setTitle("Sanal termostat").setView(content).setNegativeButton("Vazgeç",null).setPositiveButton("Kaydet",(dialog,which)->{
   try{float value=Float.parseFloat(input.getText().toString().replace(',','.'));if(value<15||value>30){message("15–30 °C arasında değer girin.");return;}
    android.content.SharedPreferences.Editor edit=getPreferences(0).edit().putFloat("thermostatSet",value).putBoolean("thermostatLive",enabled.isChecked()&&!plugs.isEmpty()&&!sensors.isEmpty());
    if(!sensors.isEmpty())edit.putString("thermostatSensor",sensors.get(spinner.getSelectedItemPosition()).id);
    if(!plugs.isEmpty())edit.putString("thermostatPlug",plugs.get(plugSpinner.getSelectedItemPosition()).id);
    edit.apply();lastThermostatCommand=0;if(enabled.isChecked()&&!plugs.isEmpty()&&!sensors.isEmpty())startThermostatService();else{stopService(new android.content.Intent(this,ThermostatService.class));if(!plugs.isEmpty())thermostatCommand(plugs.get(plugSpinner.getSelectedItemPosition()),false);}render();
   }catch(Exception ex){message("Geçersiz sıcaklık değeri.");}
  }).show();
 }
 void showClimate(){SmartSensor inside=null;for(SmartSensor sensor:smartSensors){if(sensor.air&&!capability(sensor,"temperatureMeasurement","temperature").equals("—")){inside=sensor;break;}}
  if(inside==null&&Double.isNaN(outdoorTemp))return;
  addText(body,"İç / Dış sıcaklık",19,true);gap(body,10);
  double t=inside==null?Double.NaN:numberCapability(inside,"temperatureMeasurement","temperature");
  boolean ready=!Double.isNaN(t)&&!Double.isNaN(outdoorTemp);double diff=ready?t-outdoorTemp:0;
  int tint=diff>1?0xffe86d59:diff< -1?0xff4b9fe6:0xff7f90a8;
  LinearLayout card=vertical();pad(card,18,17,18,17);card.setBackground(stroke(ready&&getPreferences(0).getBoolean("dynamicCards",true)?cardTint(tint):panel(),18,border()));body.addView(card);
  addText(card,"İçerisi: "+(Double.isNaN(t)?"—":String.format(java.util.Locale.getDefault(),"%.1f °C",t)),17,true);
  addText(card,"Dışarısı ("+weatherStatus+"): "+(Double.isNaN(outdoorTemp)?"—":String.format(java.util.Locale.getDefault(),"%.1f °C",outdoorTemp)),16,false);
  addText(card,ready?(diff>1?"İçerisi daha sıcak":diff< -1?"İçerisi daha serin":"Sıcaklıklar yakın")+"  ·  "+String.format(java.util.Locale.getDefault(),"%+.1f °C",diff):"İç/dış karşılaştırma için iki ölçüm de gerekli",13,false);
  if(weatherUpdated>0){TextView stamp=addText(card,"Dış hava güncellemesi: "+new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(new java.util.Date(weatherUpdated)),11,false);stamp.setTextColor(muted());}gap(body,18);
 }
 void recordSensorHistory(ArrayList<SmartSensor> sensors){long now=System.currentTimeMillis();for(SmartSensor sensor:sensors){if(!sensor.air)continue;String k="history_"+sensor.id;try{JSONArray arr=pref(k).isEmpty()?new JSONArray():new JSONArray(pref(k));JSONObject previous=arr.length()>0?arr.optJSONObject(arr.length()-1):null;if(previous!=null&&now-previous.optLong("time")<300000)continue;JSONObject entry=new JSONObject();entry.put("time",now);entry.put("temperature",numberCapability(sensor,"temperatureMeasurement","temperature"));entry.put("humidity",numberCapability(sensor,"relativeHumidityMeasurement","humidity"));entry.put("co2",numberCapability(sensor,"carbonDioxideMeasurement","carbonDioxide"));entry.put("pm25",pm25Number(sensor));arr.put(entry);JSONArray trimmed=new JSONArray();for(int i=0;i<arr.length();i++){JSONObject item=arr.optJSONObject(i);if(item!=null&&item.optLong("time")>=now-86400000L)trimmed.put(item);}getPreferences(0).edit().putString(k,trimmed.toString()).apply();}catch(Exception ignored){}}}
 void showSensorDetails(SmartSensor sensor){LinearLayout content=vertical();pad(content,16,12,16,12);content.setBackground(shape(panel(),16));android.widget.ScrollView scroll=new android.widget.ScrollView(this);scroll.addView(content);if(sensor.motion){addText(content,"Hareket: "+capability(sensor,"motionSensor","motion"),17,true);addText(content,"Pil: "+capability(sensor,"battery","battery")+" %",14,false);addText(content,"Hareket geçmişi henüz kaydedilmiyor.",12,false);}if(sensor.air){String[] keys={"temperature","humidity","co2","pm25"};String[] labels={"Sıcaklık · °C","Nem · %","CO₂ · ppm","PM2.5 · µg/m³"};try{JSONArray entries=new JSONArray(pref("history_"+sensor.id));long now=System.currentTimeMillis();JSONArray day=new JSONArray();for(int i=0;i<entries.length();i++){JSONObject o=entries.optJSONObject(i);if(o!=null&&o.optLong("time")>=now-86400000L)day.put(o);}addText(content,"Son 24 saat · "+day.length()+" kayıt",13,false);gap(content,12);for(int j=0;j<keys.length;j++){String key=keys[j];addText(content,labels[j],16,true);if(day.length()>=2){content.addView(new HistoryView(day,key),new LinearLayout.LayoutParams(-1,dp(155)));}else addText(content,"Grafik için en az iki ölçüm gerekli.",12,false);gap(content,16);}}catch(Exception e){addText(content,"Henüz kayıt bulunmuyor.",13,false);}}new android.app.AlertDialog.Builder(this).setTitle(sensor.name+" · Sensör detayları").setView(scroll).setPositiveButton("Kapat",null).show();}
 void showHistory(LinearLayout card,SmartSensor sensor){try{JSONArray entries=new JSONArray(pref("history_"+sensor.id));if(entries.length()<2)return;gap(card,10);TextView label=addText(card,"Son ölçümler · CO₂ (yerel kayıt)",12,true);label.setTextColor(muted());card.addView(new HistoryView(entries,"co2"),new LinearLayout.LayoutParams(-1,dp(70)));}catch(Exception ignored){}}
 class HistoryView extends View{
  final JSONArray entries;final String field;final android.graphics.Paint paint=new android.graphics.Paint(3);
  HistoryView(JSONArray data,String key){super(MainActivity.this);entries=data;field=key;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
  @Override protected void onDraw(android.graphics.Canvas canvas){
   super.onDraw(canvas);
   ArrayList<Long> times=new ArrayList<>();ArrayList<Float> values=new ArrayList<>();
   float min=Float.MAX_VALUE,max=-Float.MAX_VALUE;
   for(int i=0;i<entries.length();i++){
    JSONObject item=entries.optJSONObject(i);if(item==null)continue;
    double raw=item.optDouble(field,Double.NaN);long t=item.optLong("time",0);
    if(Double.isNaN(raw)||Double.isInfinite(raw)||raw<0||t<=0)continue;
    float v=(float)raw;times.add(t);values.add(v);min=Math.min(min,v);max=Math.max(max,v);
   }
   if(values.isEmpty())return;
   float left=dp(55),right=getWidth()-dp(12),top=dp(14),bottom=getHeight()-dp(28);
   if(right<=left||bottom<=top)return;
   float span=Math.max(1f,max-min);float pad=Math.max(span*.15f,field.equals("temperature")?.25f:field.equals("humidity")?1f:field.equals("co2")?25f:2f);
   float yMin=Math.max(0,min-pad),yMax=max+pad;float ySpan=Math.max(.01f,yMax-yMin);
   long now=System.currentTimeMillis(),start=now-86400000L;
   java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault());
   paint.setTypeface(android.graphics.Typeface.DEFAULT);paint.setTextSize(dp(10));paint.setStrokeWidth(dp(1));
   paint.setTextAlign(android.graphics.Paint.Align.RIGHT);
   for(int i=0;i<=2;i++){
    float y=bottom-(bottom-top)*i/2f;float value=yMin+(yMax-yMin)*i/2f;
    paint.setColor(0x558A9BAF);paint.setStyle(android.graphics.Paint.Style.STROKE);canvas.drawLine(left,y,right,y,paint);
    paint.setColor(0xffc0c9d8);paint.setStyle(android.graphics.Paint.Style.FILL);
    String label=field.equals("temperature")||field.equals("humidity")||field.equals("pm25")?String.format(java.util.Locale.getDefault(),"%.1f",value):String.format(java.util.Locale.getDefault(),"%.0f",value);
    canvas.drawText(label,left-dp(6),y+dp(4),paint);
   }
   paint.setTextAlign(android.graphics.Paint.Align.CENTER);paint.setColor(0xffc0c9d8);
   for(int i=0;i<=4;i++){
    long t=start+(86400000L*i/4);float x=left+(right-left)*i/4f;
    canvas.drawText(fmt.format(new java.util.Date(t)),x,bottom+dp(17),paint);
   }
   paint.setStyle(android.graphics.Paint.Style.STROKE);paint.setStrokeWidth(dp(2));paint.setColor(good());
   android.graphics.Path path=new android.graphics.Path();
   for(int i=0;i<values.size();i++){
    float x=left+(right-left)*Math.max(0f,Math.min(1f,(times.get(i)-start)/86400000f));
    float y=bottom-(bottom-top)*(values.get(i)-yMin)/ySpan;
    if(i==0)path.moveTo(x,y);else path.lineTo(x,y);
   }
   canvas.drawPath(path,paint);
   paint.setStyle(android.graphics.Paint.Style.FILL);
   for(int i=0;i<values.size();i++){
    float x=left+(right-left)*Math.max(0f,Math.min(1f,(times.get(i)-start)/86400000f));
    float y=bottom-(bottom-top)*(values.get(i)-yMin)/ySpan;
    canvas.drawCircle(x,y,dp(3),paint);
   }
  }
 }

 void all(boolean on){for(Lamp l:lamps){if(l.plug)continue;l.on=on;setLight(l.id,"{\"on\":"+on+"}");}render();}
 static class Lamp{String id,name;boolean on,color,ct,plug;int bri,hue,ctValue;}
 @Override protected void onDestroy(){refreshHandler.removeCallbacks(refreshTask);worker.shutdownNow();super.onDestroy();}
}
