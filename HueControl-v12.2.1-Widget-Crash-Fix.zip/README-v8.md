# Hue Control v8 — Dinamik kartlar (test sürümü)

- Hue lamba kartının tamamı ışık rengine göre boyanır, kapalıysa nötr kalır.
- Hue prizleri ayrı renklendirilir.
- SmartThings hava kartları CO2 ve PM2.5 ölçümlerine göre yeşil/sarı/kırmızı renge geçer.
- PIR kartları hareket algılandığında yeşil tona döner.
- Ayarlardan dinamik kartları aç/kapat ve renk yoğunluğunu ayarla.
- SmartThings uygulama açıkken yaklaşık 15 saniyede bir yenilenir.

Sınırlamalar: İç/dış sıcaklık karşılaştırması için dış hava veri kaynağı henüz yok. Hue rengi API v1 hue alanından yaklaşık hesaplanır. Android derlemesi ve cihaz testi yapılmadı.
