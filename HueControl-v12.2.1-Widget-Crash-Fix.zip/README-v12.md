# Hue Control V12 — Foreground thermostat TEST

- Foreground service polls SmartThings sensor and Hue plug every ~15 seconds, even while activity is not visible (subject to Android restrictions).
- Separate control loop replaces activity thermostat tick while live mode is enabled.
- Hysteresis +/-0.3 C; minimum 3 minutes between switching after first observed state.
- On invalid temperature / SmartThings request failure: tries to turn OFF the plug. If Hue unreachable, physical plug may stay ON.
- Notification shows latest status and errors. Weekly schedule is retained.
- Existing encrypted SmartThings token and Hue credentials are reused; no token is embedded.
- Same package ID, versionCode 15; in-place upgrade requires same signing certificate.

LIMITATIONS: Android can stop services; power/network loss may leave Hue plug ON. NO hardware watchdog is implemented. High-temperature cutoff is not a substitute for maximum-on-time watchdog. Test with boiler disconnected before unattended use. No automatic boot start. No confirmed device testing or Gradle build in this environment.
