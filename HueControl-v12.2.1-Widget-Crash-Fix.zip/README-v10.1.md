# Hue Control V10.1 — test build

New:
- Thermostat setpoint 15–30 °C, 0.5 °C steps; saved locally.
- SmartThings temperature sensor selection and simulation enable/disable.
- Heating demand preview (no real relay or boiler control).
- Hue Bridge IP defaults to 100.35.15.71 ONLY if no previous saved IP exists.
- Same applicationId com.example.huecontrol, versionCode increased to 11.
- Existing widget editing and 24-hour sensor graphs retained.

Security:
- SmartThings token is deliberately NOT embedded in source/APK. Enter once in Settings, stored encrypted via Android Keystore.
- App data is preserved on an in-place update ONLY if Android package signature is identical. GitHub Actions ephemeral default debug signing key often changes per build; use a persistent signing key securely stored as GitHub Actions secrets to enable updates. Never publish signing keys.
- The supplied SmartThings token should be revoked/rotated if it was an actual credential, since it was shared in chat.
- 100.35.15.71 is not a private LAN IPv4 address. Confirm the intended bridge address; do not expose Hue API over public HTTP.

Not implemented in this build: live boiler relay control, persistent background service, schedules, alarm center. No Android SDK build verification performed.
