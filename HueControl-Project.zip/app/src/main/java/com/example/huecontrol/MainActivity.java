package com.example.huecontrol;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
 LinearLayout root, lights; EditText ip; TextView status;
 final int bg=Color.rgb(16,20,32), fg=Color.WHITE;
 final java.util.concurrent.ExecutorService worker=Executors.newSingleThreadExecutor();
 String key(){return getPreferences(0).getString("key","");}
 String address(){return ip.getText().toString().trim();}
 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(bg);
  root=new LinearLayout(this);root.setOrientation(1);root.setPadding(28,30,28,30);scroll.addView(root);setContentView(scroll);
  label(root,"HUE CONTROL",26);label(root,"Yerel Wi-Fi üzerinden aydınlatma kontrolü",14);
  ip=new EditText(this);ip.setSingleLine(true);ip.setTextColor(fg);ip.setHintTextColor(Color.LTGRAY);ip.setHint("Bridge IP: 192.168.1.50");ip.setText(getPreferences(0).getString("ip",""));root.addView(ip);
  button(root,"Bridge ile eşleştir",()->pair());button(root,"Lambaları yenile",()->load());
  status=label(root,"Bridge IP adresini gir. Eşleştirme için Bridge düğmesine bas.",13);
  label(root,"LAMBALAR",20);lights=new LinearLayout(this);lights.setOrientation(1);root.addView(lights);
  if(!key().isEmpty()&&!address().isEmpty())load();
 }
 TextView label(LinearLayout p,String t,int size){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(fg);v.setPadding(4,12,4,12);p.addView(v);return v;}
 void button(LinearLayout p,String t,Runnable r){Button b=new Button(this);b.setText(t);b.setAllCaps(false);p.addView(b);b.setOnClickListener(v->r.run());}
 void message(String t){runOnUiThread(()->status.setText(t));}
 String request(String path,String method,String payload)throws Exception{
  String host=address();if(!host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}"))throw new Exception("Geçerli bir yerel IPv4 adresi gir.");
  HttpURLConnection c=(HttpURLConnection)new URL("http://"+host+path).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);c.setRequestMethod(method);
  if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(payload.getBytes("UTF-8"));}}
  try(InputStream in=(c.getResponseCode()<400?c.getInputStream():c.getErrorStream())){return new String(in.readAllBytes(),"UTF-8");}finally{c.disconnect();}
 }
 void pair(){
  message("Bridge üzerindeki büyük düğmeye bas, ardından eşleştirmeyi tekrar seç.");
  worker.execute(()->{try{
   String s=request("/api","POST","{\"devicetype\":\"huecontrol#android\"}");JSONArray a=new JSONArray(s);JSONObject o=a.getJSONObject(0);
   if(o.has("success")){String k=o.getJSONObject("success").getString("username");getPreferences(0).edit().putString("key",k).putString("ip",address()).apply();message("Eşleştirme başarılı.");load();}
   else message("Eşleştirme bekleniyor: Bridge düğmesine basıp yeniden dene.");
  }catch(Exception e){message("Bağlantı hatası: "+e.getMessage());}});
 }
 void load(){
  if(key().isEmpty()){message("Önce Bridge ile eşleştir.");return;}
  worker.execute(()->{try{
   JSONObject data=new JSONObject(request("/api/"+key()+"/lights","GET",null));
   runOnUiThread(()->{lights.removeAllViews();java.util.Iterator<String> ids=data.keys();while(ids.hasNext()){
    String id=ids.next();JSONObject lamp=data.optJSONObject(id);if(lamp==null)continue;JSONObject state=lamp.optJSONObject("state");String name=lamp.optString("name","Lamba "+id);
    label(lights,name,18);Switch sw=new Switch(this);sw.setText("Aç / Kapat");sw.setTextColor(fg);sw.setChecked(state!=null&&state.optBoolean("on"));lights.addView(sw);
    sw.setOnCheckedChangeListener((v,on)->setLight(id,"{\"on\":"+on+"}"));
    SeekBar dim=new SeekBar(this);dim.setMax(254);dim.setProgress(state==null?127:state.optInt("bri",127));lights.addView(dim);
    dim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int n,boolean user){}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){setLight(id,"{\"on\":true,\"bri\":"+Math.max(1,b.getProgress())+"}");}});
   }status.setText("Lambalar yüklendi.");});
  }catch(Exception e){message("Okuma hatası: "+e.getMessage());}});
 }
 void setLight(String id,String payload){worker.execute(()->{try{request("/api/"+key()+"/lights/"+id+"/state","PUT",payload);}catch(Exception e){message("Kontrol hatası: "+e.getMessage());}});}
 @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
}
