# Hue Control v6 beta

Based on the v5 Java Android project. New: 3-second local polling for external light-state changes, Philips Hue Smart Plug classification (LOM001/LOM002 and type), room brightness controls, whole-light brightness/color controls excluding plugs, same-group same-name scene filtering, and a dashboard heading update.

**Important:** This is a source-code test build, not a fully implemented visual mockup. SmartThings sensor cards, custom scene imagery, API v2 event stream, and remote access are not implemented. GitHub Actions APK compilation and hardware tests are required. Do not delete your working v5 APK before testing.

For the existing ZIP-based GitHub Actions workflow, change the unzip input to HueControl-v6-Project.zip.
