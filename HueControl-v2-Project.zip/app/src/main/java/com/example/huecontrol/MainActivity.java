package com.example.huecontrol;

import android.app.Activity;
import android.os.Bundle;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 final ExecutorService worker=Executors.newSingleThreadExecutor();
 LinearLayout shell, body, sidebar, cards, settingsPage; TextView status, connection; EditText ip;
 final ArrayList<Lamp> lamps=new ArrayList<>(); boolean dark=true; int page=0;
 int accent(){return Color.rgb(139,92,246);}
 int bg(){return dark?0xff0c1020:0xfff3f4fa;} int panel(){return dark?0xff1a2035:Color.WHITE;} int fg(){return dark?Color.WHITE:0xff202338;} int muted(){return dark?0xffa8b0c6:0xff626b80;}
 String pref(String k){return getPreferences(0).getString(k,"");}
 String address(){return pref("ip");} String key(){return pref("key");}
 int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 @Override public void onCreate(Bundle b){super.onCreate(b);dark=getPreferences(0).getBoolean("dark",true);render();if(!key().isEmpty()&&!address().isEmpty())load();}
 GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(fg());t.setTextSize(size);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
 void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
 TextView addText(LinearLayout p,String s,int size,boolean bold){TextView t=text(s,size,bold);p.addView(t);return t;}
 void button(LinearLayout p,String s,Runnable r){TextView t=text(s,14,true);t.setGravity(Gravity.CENTER);pad(t,15,13,15,13);t.setBackground(shape(accent(),12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);p.addView(t,lp);t.setOnClickListener(v->r.run());}
 void render(){
  shell=new LinearLayout(this);shell.setOrientation(1);shell.setBackgroundColor(bg());setContentView(shell);
  boolean wide=getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE;
  LinearLayout layout=new LinearLayout(this);layout.setOrientation(wide?0:1);shell.addView(layout,new LinearLayout.LayoutParams(-1,-1));
  sidebar=vertical();pad(sidebar,18,24,18,16);sidebar.setBackgroundColor(panel());
  if(wide)layout.addView(sidebar,new LinearLayout.LayoutParams(dp(205),-1));else layout.addView(sidebar,new LinearLayout.LayoutParams(-1,-2));
  addText(sidebar,"◉  HUE CONTROL",20,true);gap(sidebar,22);
  if(wide){nav("⌂  Kontrol paneli",0);nav("⚙  Ayarlar",1);}else {LinearLayout tabs=new LinearLayout(this);sidebar.addView(tabs);tab(tabs,"⌂  Kontrol",0);tab(tabs,"⚙  Ayarlar",1);}
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);layout.addView(scroll,new LinearLayout.LayoutParams(wide?0:-1,wide?-1:0,wide?1:1));
  body=vertical();pad(body,wide?28:18,25,wide?28:18,35);scroll.addView(body);
  if(page==0)showDashboard();else showSettings();
 }
 void nav(String name,int n){TextView t=text(name,16,page==n);pad(t,13,16,10,16);if(page==n)t.setBackground(shape(0xff44306e,12));sidebar.addView(t);gap(sidebar,7);t.setOnClickListener(v->{page=n;render();});}
 void tab(LinearLayout p,String name,int n){TextView t=text(name,14,page==n);pad(t,15,10,15,10);if(page==n)t.setBackground(shape(0xff44306e,10));p.addView(t);t.setOnClickListener(v->{page=n;render();});}
 void showDashboard(){addText(body,"Aydınlatma Kontrolü",27,true);gap(body,6);connection=addText(body,key().isEmpty()?"Bridge eşleştirilmedi":"● Philips Hue Bridge • "+address(),13,false);connection.setTextColor(muted());gap(body,22);
  LinearLayout actions=vertical();body.addView(actions);button(actions,"Tümünü aç",()->all(true));button(actions,"Tümünü kapat",()->all(false));
  gap(body,16);addText(body,"Lambalar",21,true);gap(body,12);
  cards=vertical();body.addView(cards);
  if(lamps.isEmpty())addText(cards,"Henüz lamba yüklenmedi. Ayarlar bölümünden Bridge bağlantısını yapıp lambaları yenileyin.",15,false);
  else drawCards();
  gap(body,18);status=addText(body,"",13,false);status.setTextColor(muted());
 }
 void drawCards(){cards.removeAllViews();int width=getResources().getDisplayMetrics().widthPixels;int cols=getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE?(width>dp(1000)?3:2):1;
  LinearLayout line=null;for(int i=0;i<lamps.size();i++){if(i%cols==0){line=new LinearLayout(this);cards.addView(line,new LinearLayout.LayoutParams(-1,-2));}Lamp l=lamps.get(i);LinearLayout card=vertical();pad(card,17,17,17,16);card.setBackground(shape(panel(),18));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.setMargins(dp(5),dp(5),dp(5),dp(7));line.addView(card,cp);
   LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);card.addView(top);TextView name=text(l.name,17,true);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));Switch sw=new Switch(this);sw.setChecked(l.on);top.addView(sw);sw.setOnCheckedChangeListener((v,on)->{l.on=on;setLight(l.id,"{\"on\":"+on+"}");});
   gap(card,12);TextView pct=addText(card,"Parlaklık  "+Math.round(l.bri*100f/254)+"%",13,false);pct.setTextColor(muted());SeekBar dim=new SeekBar(this);dim.setMax(254);dim.setProgress(l.bri);card.addView(dim);dim.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean user){if(user)pct.setText("Parlaklık  "+Math.round(p*100f/254)+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){l.bri=Math.max(1,s.getProgress());setLight(l.id,"{\"on\":true,\"bri\":"+l.bri+"}");}});
   if(l.color){gap(card,7);TextView hue=addText(card,"Renk",13,false);hue.setTextColor(muted());SeekBar h=new SeekBar(this);h.setMax(65535);h.setProgress(l.hue);card.addView(h);h.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){l.hue=p;setLight(l.id,"{\"on\":true,\"hue\":"+p+",\"sat\":254}");}});}
   if(l.ct){gap(card,7);TextView ct=addText(card,"Beyaz sıcaklığı • Sıcak ↔ Soğuk",12,false);ct.setTextColor(muted());SeekBar temp=new SeekBar(this);temp.setMax(347);temp.setProgress(Math.max(0,Math.min(347,500-l.ctValue)));card.addView(temp);temp.setOnSeekBarChangeListener(new StopSeek(){public void stopped(int p){l.ctValue=500-p;setLight(l.id,"{\"on\":true,\"ct\":"+l.ctValue+"}");}});}
  }
 }
 abstract class StopSeek implements SeekBar.OnSeekBarChangeListener{public void onProgressChanged(SeekBar s,int p,boolean u){}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){stopped(s.getProgress());}public abstract void stopped(int p);}
 void showSettings(){addText(body,"Ayarlar",27,true);gap(body,20);addText(body,"Hue Bridge bağlantısı",20,true);gap(body,8);ip=new EditText(this);ip.setSingleLine(true);ip.setTextColor(fg());ip.setHintTextColor(muted());ip.setHint("Bridge yerel IP adresi");ip.setText(address());body.addView(ip);gap(body,10);
  button(body,"IP adresini kaydet",()->{String a=ip.getText().toString().trim();if(!validIp(a)){message("Geçerli IPv4 adresi girin.");return;}getPreferences(0).edit().putString("ip",a).apply();message("Bridge IP kaydedildi.");});
  button(body,"Bridge ile eşleştir",()->pair());button(body,"Lambaları yenile",()->load());
  status=addText(body,key().isEmpty()?"Bridge henüz eşleştirilmedi.":"Bridge anahtarı kayıtlı.",13,false);status.setTextColor(muted());gap(body,24);
  addText(body,"Görünüm",20,true);Switch theme=new Switch(this);theme.setText("Koyu tema");theme.setTextColor(fg());theme.setTextSize(16);theme.setChecked(dark);body.addView(theme);theme.setOnCheckedChangeListener((v,on)->{dark=on;getPreferences(0).edit().putBoolean("dark",on).apply();render();});gap(body,24);
  addText(body,"Tüm lambalar ("+lamps.size()+")",20,true);gap(body,10);for(Lamp l:lamps){TextView t=addText(body,"• "+l.name+"   (ID: "+l.id+")",15,false);pad(t,5,9,5,9);}gap(body,20);addText(body,"Hue Control v2 • Yerel ağ üzerinden kontrol",12,false);
 }
 boolean validIp(String a){if(!a.matches("\\d{1,3}(\\.\\d{1,3}){3}"))return false;for(String part:a.split("\\."))if(Integer.parseInt(part)>255)return false;return true;}
 void message(String m){runOnUiThread(()->{if(status!=null)status.setText(m);else Toast.makeText(this,m,Toast.LENGTH_LONG).show();});}
 String request(String host,String path,String method,String payload)throws Exception{if(!validIp(host))throw new Exception("Geçersiz IP");HttpURLConnection c=(HttpURLConnection)new URL("http://"+host+path).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);c.setRequestMethod(method);if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(payload.getBytes("UTF-8"));}}try(InputStream in=c.getResponseCode()<400?c.getInputStream():c.getErrorStream()){if(in==null)throw new Exception("HTTP "+c.getResponseCode());return new String(in.readAllBytes(),"UTF-8");}finally{c.disconnect();}}
 void pair(){String host=ip==null?address():ip.getText().toString().trim();if(!validIp(host)){message("Önce geçerli IP girin.");return;}getPreferences(0).edit().putString("ip",host).apply();message("Bridge düğmesine basın ve tekrar eşleştirmeyi deneyin.");worker.execute(()->{try{JSONArray a=new JSONArray(request(host,"/api","POST","{\"devicetype\":\"huecontrol#android\"}"));JSONObject o=a.getJSONObject(0);if(o.has("success")){String k=o.getJSONObject("success").getString("username");getPreferences(0).edit().putString("key",k).apply();message("Eşleştirme başarılı.");load();}else message("Bridge düğmesine basın: "+o.optJSONObject("error").optString("description","Eşleştirme bekleniyor"));}catch(Exception e){message("Bağlantı hatası: "+e.getMessage());}});}
 void load(){String host=address(),token=key();if(token.isEmpty()||host.isEmpty()){message("Önce Bridge ile eşleştirin.");return;}worker.execute(()->{try{JSONObject data=new JSONObject(request(host,"/api/"+token+"/lights","GET",null));ArrayList<Lamp> fresh=new ArrayList<>();Iterator<String> ids=data.keys();while(ids.hasNext()){String id=ids.next();JSONObject o=data.optJSONObject(id);if(o==null)continue;JSONObject st=o.optJSONObject("state");if(st==null)st=new JSONObject();JSONObject caps=o.optJSONObject("capabilities");JSONObject control=caps==null?null:caps.optJSONObject("control");Lamp l=new Lamp();l.id=id;l.name=o.optString("name","Lamba "+id);l.on=st.optBoolean("on");l.bri=st.optInt("bri",127);l.hue=st.optInt("hue",0);l.ctValue=st.optInt("ct",350);String type=o.optString("type","");l.color=st.has("hue")||type.contains("color light");l.ct=st.has("ct")||type.contains("temperature");if(control!=null&&control.has("ct"))l.ct=true;fresh.add(l);}Collections.sort(fresh,(a,b)->a.name.compareToIgnoreCase(b.name));runOnUiThread(()->{lamps.clear();lamps.addAll(fresh);render();message(lamps.size()+" lamba yüklendi.");});}catch(Exception e){message("Okuma hatası: "+e.getMessage());}});}
 void setLight(String id,String payload){String host=address(),token=key();worker.execute(()->{try{String result=request(host,"/api/"+token+"/lights/"+id+"/state","PUT",payload);JSONArray a=new JSONArray(result);if(a.length()>0&&a.getJSONObject(0).has("error"))message("Hue hatası: "+a.getJSONObject(0).getJSONObject("error").optString("description"));}catch(Exception e){message("Kontrol hatası: "+e.getMessage());}});}
 void all(boolean on){for(Lamp l:lamps){l.on=on;setLight(l.id,"{\"on\":"+on+"}");}render();}
 static class Lamp{String id,name;boolean on,color,ct;int bri,hue,ctValue;}
 @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
}
